package me.southernseth.p2pfs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;

import javax.crypto.Cipher;

public class RSAUtil {

	/**
	 * String to hold name of the encryption algorithm for RSA.
	 */
	public static final String ALGORITHM_RSA = "RSA";

	/**
	 * String to hold the name of the private key file.
	 */
	public static final String PRIVATE_KEY_FILE = ".P2PFILESHARE" + "\\" + "private.key";

	/**
	 * String to hold name of the public key file.
	 */
	public static final String PUBLIC_KEY_FILE = ".P2PFILESHARE" + "\\" + "public.key";
	
	/**
	 * PublicKey object for encrypting messages.
	 */
	public static PublicKey PUBLIC_KEY;
	
	/**
	 * PrivateKey object for decrypting messages.
	 */
	public static PrivateKey PRIVATE_KEY;
	
	/**
	 * This loads the PUBLIC_KEY and PRIVATE_KEY objects into memory for use in decrypting and encrypting text
	 * 
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static void loadKeys() throws IOException, ClassNotFoundException {
		FileInputStream fis = new FileInputStream(RSAUtil.PUBLIC_KEY_FILE);
		ObjectInputStream ois = new ObjectInputStream(fis);
		PublicKey pubKey = (PublicKey) ois.readObject();
		ois.close();
		
		FileInputStream fis2 = new FileInputStream(RSAUtil.PRIVATE_KEY_FILE);
		ObjectInputStream ois2 = new ObjectInputStream(fis2);
		PrivateKey privKey = (PrivateKey) ois2.readObject();
		ois2.close();
		
		PUBLIC_KEY = pubKey;
		PRIVATE_KEY = privKey;
	}

	/**
	 * Generate key which contains a pair of private and public key using 1024
	 * bytes. Store the set of keys in Prvate.key and Public.key files.
	 * 
	 * @throws NoSuchAlgorithmException
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void generateKeys() {
		try {
			final KeyPairGenerator keyGen = KeyPairGenerator.getInstance(ALGORITHM_RSA);
			SecureRandom random = SecureRandom.getInstanceStrong();
			byte[] seed = random.generateSeed(55);
			random.setSeed(seed);
			keyGen.initialize(2048, random);
			final KeyPair key = keyGen.generateKeyPair();
			
			File privateKeyFile = new File(PRIVATE_KEY_FILE);
			File publicKeyFile = new File(PUBLIC_KEY_FILE);

			if (privateKeyFile.getParentFile() != null) {
				privateKeyFile.getParentFile().mkdirs();
			}
			privateKeyFile.createNewFile();

			if (publicKeyFile.getParentFile() != null) {
				publicKeyFile.getParentFile().mkdirs();
			}
			publicKeyFile.createNewFile();

			ObjectOutputStream publicKeyOS = new ObjectOutputStream(
					new FileOutputStream(publicKeyFile));
			publicKeyOS.writeObject(key.getPublic());
			publicKeyOS.close();

			ObjectOutputStream privateKeyOS = new ObjectOutputStream(
					new FileOutputStream(privateKeyFile));
			privateKeyOS.writeObject(key.getPrivate());
			privateKeyOS.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * The method checks if the pair of public and private key has been generated.
	 * 
	 * @return flag indicating if the pair of keys were generated.
	 */
	public static boolean areKeysPresent() {
		File privateKey = new File(PRIVATE_KEY_FILE);
		File publicKey = new File(PUBLIC_KEY_FILE);
		if (privateKey.exists() && publicKey.exists()) {
			return true;
		}
		return false;
	}

	/**
	 * Encrypt the plain text using public key.
	 * 
	 * @param text
	 *          : original plain text
	 * @param key
	 *          :The public key
	 * @return Encrypted text
	 * @throws Exception
	 */
	public static byte[] encrypt(String text, PublicKey key) {
		byte[] cipherText = null;
		try {
			final Cipher cipher = Cipher.getInstance(ALGORITHM_RSA);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			cipherText = cipher.doFinal(text.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cipherText;
	}

	/**
	 * Decrypt text using private key.
	 * 
	 * @param text
	 *          :encrypted text
	 * @param key
	 *          :The private key
	 * @return plain text
	 * @throws Exception
	 */
	public static String decrypt(byte[] text, PrivateKey key) {
		byte[] dectyptedText = null;
		try {
			final Cipher cipher = Cipher.getInstance(ALGORITHM_RSA);
			cipher.init(Cipher.DECRYPT_MODE, key);
			dectyptedText = cipher.doFinal(text);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return new String(dectyptedText);
	}
}
