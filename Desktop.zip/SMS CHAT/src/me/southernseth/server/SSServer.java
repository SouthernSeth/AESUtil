package me.southernseth.server;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.Enumeration;
import java.util.Random;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import com.esotericsoftware.kryonet.Server;

import me.southernseth.client.SSClient;
import me.southernseth.networking.Network;
import me.southernseth.networking.User;
import me.southernseth.networking.packets.DisconnectPacket;
import me.southernseth.networking.packets.JoinPacket;
import me.southernseth.networking.packets.MessagePacket;
import me.southernseth.networking.packets.UpdateUsername;
import me.southernseth.networking.packets.UserList;

public class SSServer {

	private Server server;

	private int maxAttendees;

	public int connected = 0;

	private User[] connected_users;

	private SSClient client;

	public SSServer(int maxAttendees, SSClient client) {
		this.client = client;
		this.maxAttendees = maxAttendees;
		connected_users = new User[maxAttendees];

		init();
	}

	public void init() {
		server = new Server();
		Network.register(server);

		server.addListener(new Listener() {
			@Override
			public void received(Connection c, Object o) {
				if (o instanceof JoinPacket) {
					JoinPacket packet = (JoinPacket) o;

					ArrayList<String> usernameList = new ArrayList<String>();
					for (int i = 0;i<connected_users.length;i++) {
						User u = connected_users[i];

						if (u == null) {
							break;
						}

						if (!usernameList.contains(u.getUsername())) {
							usernameList.add(u.getUsername());
						}
					}

					while (usernameList.contains(packet.username)) {
						packet.username = packet.username + "_" + System.currentTimeMillis();
					}

					if (connected >= maxAttendees) {
						MessagePacket packet2 = new MessagePacket();
						SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
						packet2.timestamp = sdf.format(new Date());
						packet2.msg = Base64.getEncoder().encodeToString("The server you tried connecting to is full!".getBytes());
						packet2.username = "server";
						c.sendTCP(packet2);
						c.close();
						return;
					} else {
						int id = generateID();
						User user = new User(id, packet.username);
						for (int i = 0;i<connected_users.length;i++) {
							if (connected_users[i] == null) {
								if (packet.host) {
									user.setHost(true);
									user.setUsername(packet.username);
								}

								connected_users[i] = user;
								break;
							}
						}
						packet.id = id;
						c.sendTCP(packet);
						connected++;
						
						MessagePacket packet2 = new MessagePacket();
						SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
						packet2.timestamp = sdf.format(new Date());
						packet2.msg = Base64.getEncoder().encodeToString("Welcome to the chat server".getBytes());
						packet2.username = "server";
						c.sendTCP(packet2);
						
						MessagePacket packet4 = new MessagePacket();
						packet4.timestamp = sdf.format(new Date());
						packet4.msg = Base64.getEncoder().encodeToString(("This server's IP is " + getIP()).getBytes());
						packet4.username = "server";
						c.sendTCP(packet4);

						MessagePacket packet3 = new MessagePacket();
						packet3.timestamp = sdf.format(new Date());
						packet3.msg = Base64.getEncoder().encodeToString((packet.username + " has connected to the server").getBytes());
						packet3.username = "server";
						server.sendToAllTCP(packet3);

						updateUserList();
					}
				} else if (o instanceof DisconnectPacket) {
					DisconnectPacket packet = (DisconnectPacket) o;
					for (int i = 0;i<connected_users.length;i++) {
						if (connected_users[i] != null) {
							User user = connected_users[i];
							if (user.getUsername().equalsIgnoreCase(packet.username)) {
								connected_users[i] = null;
								connected--;
								MessagePacket packet3 = new MessagePacket();
								SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
								packet3.timestamp = sdf.format(new Date());
								packet3.msg = Base64.getEncoder().encodeToString((packet.username + " disconnected from the server").getBytes());
								packet3.username = "server";
								server.sendToAllTCP(packet3);
								break;
							}
						}
					}

					updateUserList();
				} else if (o instanceof MessagePacket) {
					MessagePacket packet = (MessagePacket) o;
					SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
					User user = null;
					int index = 0;
					String decoded = new String(Base64.getDecoder().decode(packet.msg));

					for (int i = 0;i<connected_users.length;i++) {
						user = connected_users[i];
						if (user.getID() == packet.id) {
							index = i;
							try {
								user.recordMessage(sdf.parse(packet.timestamp), decoded);
							} catch (ParseException e) {
								e.printStackTrace();
							}
							break;
						}
					}

					connected_users[index] = user;

					server.sendToAllTCP(packet);
				} else if (o instanceof UpdateUsername) {
					UpdateUsername packet = (UpdateUsername) o;
					for (int i = 0;i<connected_users.length;i++) {
						if (connected_users[i] != null) {
							String name = connected_users[i].getUsername().replace("[Host] ", "");
							if (name.equalsIgnoreCase(packet.currentUsername)) {
								connected_users[i].setUsername(packet.newUsername);
								updateUserList();
								MessagePacket packet2 = new MessagePacket();
								SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
								packet2.timestamp = sdf.format(new Date());
								packet2.msg = Base64.getEncoder().encodeToString((packet.currentUsername + " is now known as " + packet.newUsername).getBytes());
								packet2.username = "server";
								server.sendToAllTCP(packet2);
								return;
							}
						}
					}
				}
			}
		});

		server.start();

		try {
			InetSocketAddress address = new InetSocketAddress("0.0.0.0", Network.TCP_PORT);
			server.bind(address, null);
			Network.serverLog("Server started on TCP port " + Network.TCP_PORT);
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			client.client.connect(10000, "0.0.0.0", Network.TCP_PORT);

			JoinPacket packet = new JoinPacket();
			packet.id = 0;
			packet.username = client.username;
			packet.host = true;
			client.client.sendTCP(packet);

			Network.clientLog("Connected to server: " + client.client.getRemoteAddressTCP());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		server.close();
	}

	public void updateUserList() {
		UserList userList = new UserList();
		StringBuilder builder = new StringBuilder();
		for (int i = 0;i<connected_users.length;i++) {
			if (connected_users[i] != null) {
				if (connected_users[i].isHost()) {
					builder.append("<b>" + connected_users[i].getUsername() + "</b><br>");
				} else {
					builder.append(connected_users[i].getUsername() + "<br>");
				}
			}
		}
		userList.userList = builder.toString();
		server.sendToAllTCP(userList);
	}

	private int generateID() {
		Random r = new Random();

		boolean usedID = false;

		int id = r.nextInt(maxAttendees);

		if (connected > 1) {
			do {
				usedID = false;

				for (int i = 0;i<connected_users.length;i++) {
					if (connected_users[i] == null) {
						//DO NOTHING
					} else {
						User u = connected_users[i];
						if (u.getID() == id) {
							id = r.nextInt(maxAttendees);
							usedID = true;
						}
					}
				}
			} while (usedID);

			return id;
		} else {
			return id;
		}
	}
	
	public String getIP() {
		String ip = null;
		try {
			Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			while (interfaces.hasMoreElements()) {
				NetworkInterface iface = interfaces.nextElement();
				if (iface.isLoopback() || !iface.isUp())
					continue;

				Enumeration<InetAddress> addresses = iface.getInetAddresses();
				while(addresses.hasMoreElements()) {
					InetAddress addr = addresses.nextElement();
					if (iface.getDisplayName().contains("Juniper") && !addr.getHostAddress().contains(":")) {
						ip = addr.getHostAddress();
						System.out.println(iface.getDisplayName() + " " + ip);
					}
				}
			}
		} catch (SocketException e) {
			throw new RuntimeException(e);
		}

		if (ip == null) {
			return "Boeing VPN not connected";
		} else {
			return ip;
		}
	}

}
