package me.southernseth.client;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultCaret;
import javax.swing.text.html.HTMLDocument;

import com.esotericsoftware.kryonet.Client;
import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;

import me.southernseth.networking.Network;
import me.southernseth.networking.packets.DisconnectPacket;
import me.southernseth.networking.packets.JoinPacket;
import me.southernseth.networking.packets.MessagePacket;
import me.southernseth.networking.packets.UpdateUsername;
import me.southernseth.networking.packets.UserList;
import me.southernseth.server.SSServer;

public class SSClient {

	public Client client;
	public SSServer server;

	public JFrame window;
	public JPanel panel;

	public String username = "Default";
	public int id;

	public JTextPane userList;
	public JTextPane textArea;

	public final Object monitor = new Object();
	public boolean monitorState = false;

	public boolean isHost = false;

	public String lastConnectedIP;

	public SSClient() {
		client = new Client();
		Network.register(client);

		client.addListener(new Listener() {
			@Override
			public void received(Connection c, Object o) {
				if (o instanceof JoinPacket) {
					JoinPacket packet = (JoinPacket) o;
					id = packet.id;
				} else if (o instanceof UserList) {
					UserList packet = (UserList) o;
					userList.setText("");
					userList.setText(packet.userList);
				} else if (o instanceof MessagePacket) {
					MessagePacket packet = (MessagePacket) o;
					String decoded = new String(Base64.getDecoder().decode(packet.msg));
					if (packet.username.equalsIgnoreCase("server")) {
						append("<font color=\"red\"><b>[" + "SERVER" + " @ " + packet.timestamp + "] " + decoded + "</b></font>");
					} else {
						append("<b>[" + packet.username + " @ " + packet.timestamp + "]</b> " + decoded);
					}
				}
			}

			@Override
			public void disconnected(Connection c) {
				append("<font color=\"red\"><b>YOU WERE DISCONNECTED FROM THE SERVER (THE SERVER CLOSED)</b></font>");
			}
		});

		client.start();

		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.setPreferredSize(new Dimension(800, 475));

		setupUI();

		window = new JFrame("SouthernSeth's SMS Chat");
		window.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		try {
			window.setIconImage(ImageIO.read(getClass().getResourceAsStream("/icon.png")));
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		window.add(panel);
		window.pack();
		window.setMinimumSize(new Dimension(window.getSize().width, window.getSize().height));
		window.setLocationRelativeTo(null);
		window.setVisible(true);

		window.addWindowListener(new WindowListener() {

			@Override
			public void windowActivated(WindowEvent e) {
			}

			@Override
			public void windowClosed(WindowEvent e) {
			}

			@Override
			public void windowClosing(WindowEvent e) {
				DisconnectPacket packet = new DisconnectPacket();
				packet.id = id;
				packet.username = username;
				client.sendTCP(packet);

				window.dispose();
				System.exit(1);
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
			}

			@Override
			public void windowIconified(WindowEvent e) {
			}

			@Override
			public void windowOpened(WindowEvent e) {
			}

		});
	}

	public void host() {
		isHost = true;
		server = new SSServer(10, this);
	}

	public void setupUI() {
		panel.removeAll();

		JTextField input = new JTextField();

		userList = new JTextPane();
		userList.setEditable(false);
		userList.setContentType("text/html");

		textArea = new JTextPane();
		textArea.setEditable(false);
		textArea.setAutoscrolls(true);
		textArea.setContentType("text/html");

		DefaultCaret caret = (DefaultCaret)textArea.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

		JScrollPane userListPane = new JScrollPane(userList);
		JScrollPane scrollPane = new JScrollPane(textArea);
		userListPane.setName("userListPane");

		int width = (int) (panel.getSize().width * .25);
		int height = panel.getSize().height;
		userListPane.setPreferredSize(new Dimension(width, height));

		width = (int) (panel.getSize().width * .75);
		scrollPane.setPreferredSize(new Dimension(width, height));

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		panel.add(scrollPane, gbc);

		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 0.5;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2;
		panel.add(input, gbc);

		panel.revalidate();
		panel.repaint();

		append("Use <font color=\"red\"><b>/connect [ip]</b></font> to join someone's chat server" + "<br>" 
				+ "Use <font color=\"red\"><b>/host</b></font> to host your own chat server" + "<br>"  
				+ "Use <font color=\"red\"><b>/username [username]</b></font> to set your username" + "<br>"
				+ "Use <font color=\"red\"><b>/disconnect</b></font> to leave a server that you are connected to" + "<br>"
				+ "Use <font color=\"red\"><b>/reconnect</b></font> to try and reconnect to the last server you joined" + "<br>");

		input.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String[] splitCommand = input.getText().split(" ");

					if (input.getText().startsWith("/connect")) {
						if (splitCommand.length != 2) {
							append("<font color=\"red\"><b>[Command] Usage: /connect [ip]</b></font>");
							input.setText("");
						} else {
							try {
								client.connect(10000, splitCommand[1], Network.TCP_PORT);
								lastConnectedIP = splitCommand[1];

								JoinPacket packet = new JoinPacket();
								packet.id = 0;
								packet.username = username;
								client.sendTCP(packet);

								Network.clientLog("Connected to server: " + client.getRemoteAddressTCP());

								for (int i = 0;i<panel.getComponentCount();i++) {
									if (panel.getComponent(i) instanceof JScrollPane) {
										JScrollPane pane = (JScrollPane) panel.getComponent(i);
										String name = pane.getName();
										if (name != null) {
											if (name.equalsIgnoreCase("userListPane")) {
												panel.remove(i);
												break;
											}
										}
									}
								}

								GridBagConstraints gbc = new GridBagConstraints();
								gbc.fill = GridBagConstraints.BOTH;
								gbc.weightx = 0.2;
								gbc.weighty = 1;
								gbc.gridx = 1;
								gbc.gridy = 0;
								panel.add(userListPane, gbc);

								panel.revalidate();
								panel.repaint();

								clear();
							} catch (IOException e2) {
								e2.printStackTrace();
								append(e2.getLocalizedMessage());
							}
							input.setText("");
						}
						return;
					} else if (input.getText().startsWith("/host")) {
						if (client.isConnected()) {
							input.setText("");
							return;
						}

						if (splitCommand.length == 1) {
							GridBagConstraints gbc = new GridBagConstraints();
							gbc.fill = GridBagConstraints.BOTH;
							gbc.weightx = 0.2;
							gbc.weighty = 1;
							gbc.gridx = 1;
							gbc.gridy = 0;
							panel.add(userListPane, gbc);

							panel.revalidate();
							panel.repaint();

							clear();
							host();
							input.setText("");
						} else if (splitCommand.length >= 2) {
							append("<font color=\"red\"><b>[Command] Usage: /host</b></font>");
							input.setText("");
						}
						return;
					} else if (input.getText().startsWith("/nick") || input.getText().startsWith("/username") || input.getText().startsWith("/nickname")) {
						if (splitCommand.length == 2) {
							if (client.isConnected()) {
								UpdateUsername packet = new UpdateUsername();
								packet.currentUsername = username;
								username = splitCommand[1];
								packet.newUsername = username;
								client.sendTCP(packet);
							} else {
								username = splitCommand[1];
							}
							append("<font color=\"red\"><b>Username has been changed to: " + splitCommand[1] + "</b></font>");
							input.setText("");
						} else {
							append("<font color=\"red\"><b>[Command] Usage: /nick | /nickname | /username [username]</b></font>");
							input.setText("");
						}
						return;
					} else if (input.getText().startsWith("/disconnect")) {
						if (splitCommand.length == 1) {
							if (!client.isConnected()) {
								append("<font color=\"red\"><b>You are currently not connect to a server</b></font>");
								input.setText("");
								return;
							}

							if (isHost) {
								server.close();
							}
							client.close();
							for (int i = 0;i<panel.getComponentCount();i++) {
								if (panel.getComponent(i) instanceof JScrollPane) {
									JScrollPane pane = (JScrollPane) panel.getComponent(i);
									String name = pane.getName();
									if (name != null) {
										if (name.equalsIgnoreCase("userListPane")) {
											panel.remove(i);
											break;
										}
									}
								}
							}
							panel.revalidate();
							panel.repaint();
							clear();
							append("Use <font color=\"red\"><b>/connect [ip]</b></font> to join someone's chat server" + "<br>" 
									+ "Use <font color=\"red\"><b>/host</b></font> to host your own chat server" + "<br>" 
									+ "Use <font color=\"red\"><b>/host collab</b></font> to host your own document collaboration server" + "<br>" 
									+ "Use <font color=\"red\"><b>/username [username]</b></font> to set your username" + "<br>"
									+ "Use <font color=\"red\"><b>/disconnect</b></font> to leave a server that you are connected to" + "<br>"
									+ "Use <font color=\"red\"><b>/reconnect</b></font> to try and reconnect to the last server you joined" + "<br>");
							input.setText("");
						} else {
							append("<font color=\"red\"><b>[Command] Usage: /disconnect</b></font>");
							input.setText("");
						}
						return;
					} else if (input.getText().startsWith("/reconnect")) {
						if (lastConnectedIP == null) {
							append("<font color=\"red\"><b>You have not connected to a server yet</b></font>");
							input.setText("");
							return;
						}

						if (splitCommand.length == 1) {
							try {
								client.connect(10000, lastConnectedIP, Network.TCP_PORT);

								JoinPacket packet = new JoinPacket();
								packet.id = 0;
								packet.username = username;
								client.sendTCP(packet);

								Network.clientLog("Connected to server: " + client.getRemoteAddressTCP());

								for (int i = 0;i<panel.getComponentCount();i++) {
									if (panel.getComponent(i) instanceof JScrollPane) {
										JScrollPane pane = (JScrollPane) panel.getComponent(i);
										String name = pane.getName();
										if (name != null) {
											if (name.equalsIgnoreCase("userListPane")) {
												panel.remove(i);
												break;
											}
										}
									}
								}

								GridBagConstraints gbc = new GridBagConstraints();
								gbc.fill = GridBagConstraints.BOTH;
								gbc.weightx = 0.2;
								gbc.weighty = 1;
								gbc.gridx = 1;
								gbc.gridy = 0;
								panel.add(userListPane, gbc);

								panel.revalidate();
								panel.repaint();

								clear();
							} catch (IOException e2) {
								e2.printStackTrace();
								append(e2.getLocalizedMessage());
							}
							input.setText("");
						} else {
							append("<font color=\"red\"><b>[Command] Usage: /reconnect</b></font>");
							input.setText("");
						}
						return;
					}

					SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");

					MessagePacket packet = new MessagePacket();
					packet.id = id;
					packet.username = username;
					packet.timestamp = sdf.format(new Date());
					packet.msg = Base64.getEncoder().encodeToString(input.getText().getBytes());

					client.sendTCP(packet);

					input.setText("");
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {

			}

			@Override
			public void keyTyped(KeyEvent e) {

			}

		});
	}

	public void clear() {
		textArea.setText("");
	}

	public void append(String text) {
		if (textArea.getStyledDocument().getLength() != 0) {
			text = "<br>" + text;
		}

		HTMLDocument doc = (HTMLDocument) textArea.getStyledDocument();
		try {
			doc.insertAfterEnd(doc.getCharacterElement(doc.getLength()),text);
		} catch (BadLocationException | IOException e) {
			e.printStackTrace();
		}
		textArea.setDocument(doc);
	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		new SSClient();
	}

}
