package me.southernseth.networking.packets;

public class JoinPacket {
	
	public int id;
	public String username;
	public boolean host;

}
