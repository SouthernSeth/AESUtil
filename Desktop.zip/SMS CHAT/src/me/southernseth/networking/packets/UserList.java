package me.southernseth.networking.packets;

public class UserList {
	
	public String userList;

}
