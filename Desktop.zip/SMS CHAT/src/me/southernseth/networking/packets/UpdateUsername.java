package me.southernseth.networking.packets;

public class UpdateUsername {
	
	public String currentUsername;
	public String newUsername;

}
