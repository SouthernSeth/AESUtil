package me.southernseth.networking.packets;

public class MessagePacket {
	
	public int id;
	public String username;
	public String timestamp;
	public String msg;

}
