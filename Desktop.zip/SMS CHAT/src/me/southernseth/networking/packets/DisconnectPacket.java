package me.southernseth.networking.packets;

public class DisconnectPacket {
	
	public int id;
	public String username;

}
