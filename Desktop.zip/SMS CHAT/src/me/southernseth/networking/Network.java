package me.southernseth.networking;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.EndPoint;

import me.southernseth.networking.packets.DisconnectPacket;
import me.southernseth.networking.packets.JoinPacket;
import me.southernseth.networking.packets.MessagePacket;
import me.southernseth.networking.packets.UpdateUsername;
import me.southernseth.networking.packets.UserList;

public class Network {
	
	public static final int TCP_PORT = 54555;
	public static final int UDP_PORT = 54777;
	
	public static void register(EndPoint endPoint) {
		Kryo kryo = endPoint.getKryo();
		
		kryo.register(int.class);
		kryo.register(String.class);
		kryo.register(boolean.class);
		kryo.register(JoinPacket.class);
		kryo.register(DisconnectPacket.class);
		kryo.register(MessagePacket.class);
		kryo.register(UserList.class);
		kryo.register(UpdateUsername.class);
	}
	
	public static void clientLog(String message) {
		System.out.println("[Client] " + message);
	}
	
	public static void serverLog(String message) {
		System.out.println("[Server] " + message);
	}

}
