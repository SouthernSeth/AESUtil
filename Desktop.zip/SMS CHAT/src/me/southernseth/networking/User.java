package me.southernseth.networking;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class User {
	
	private int id;
	private String username;
	private boolean host = false;
	
	private HashMap<String, String> messageHistory = new HashMap<String, String>();
	
	public User() {
	}
	
	public User(int id, String username) {
		this.id = id;
		this.username = username;
	}
	
	public int getID() {
		return id;
	}
	
	public String getUsername() {
		return username;
	}
	
	public boolean isHost() {
		return host;
	}
	
	public HashMap<String, String> getMessageHistory() {
		return messageHistory;
	}
	
	public void setHost(boolean host) {
		this.host = host;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public void setID(int id) {
		this.id = id;
	}
	
	public void recordMessage(Date date, String message) {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
		String formattedDate = sdf.format(date);
		messageHistory.put(formattedDate, message);
	}

}
