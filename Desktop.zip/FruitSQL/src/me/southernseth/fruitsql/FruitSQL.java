package me.southernseth.fruitsql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Jordan Wiggins
 *
 */

/*
 * Example use:
 *
 * FruitSQL sql = new FruitSQL("host", "port", "database", "username",
 * "password"); //Connect to database
 * sql.createTable("users"); //Create the table 'users'
 * 
 * YOU MUST HAVE JDBC TO USE FRUITSQL
 */

public class FruitSQL {

	// Variable that holds our MySQL database connection
	private Connection connection = null;

	// Variables that hold the MySQL database connection information
	private String host, port, database, username, password;

	/**
	 * Initialize the FruitSQL object and connect to the database with the specified username and password
	 *
	 * @param host
	 * @param port
	 * @param database
	 * @param username
	 * @param password
	 * 
	 * @exception SQLException
	 * @exception ClassNotFoundException
	 */
	public FruitSQL(String host, String port, String database, String username, String password) {
		long start = 0;
		long end = 0;

		this.host = host;
		this.port = port;
		this.database = database;
		this.username = username;
		this.password = password;

		try {
			start = System.currentTimeMillis();

			System.out.println("Attempting to establish a connection the MySQL server!");

			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database, username, password);

			end = System.currentTimeMillis();

			System.out.println("Connection to MySQL server established! (" + host + ":" + port + ")");
			System.out.println("Connection took " + ((end - start)) + "ms!");
		} catch (SQLException e) {
			System.out.println("Could not connect to MySQL server! because: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC Driver not found!");
		}
	}

	/**
	 * Returns whether there is an active connection to the MySQL database
	 *
	 * @return boolean
	 */
	public boolean isConnected() {
		if (connection != null) { 
			return true; 
		}

		return false;
	}

	/**
	 * Closes the connection to the MySQL server
	 * 
	 * @exception SQLException
	 */
	public void closeConnection() {
		if (connection == null) {
			try {
				connection.close();
				System.out.println("MySQL Connection closed");
			} catch (SQLException e) {
				System.out.println("Couldn't close connection");
			}
		}
	}

	/**
	 * Refreshes the connection to the MySQL database
	 * 
	 * @exception SQLException
	 * @exception ClassNotFoundException
	 */
	public void refreshConnection() {
		PreparedStatement st = null;
		ResultSet valid = null;

		try {
			st = connection.prepareStatement("SELECT 1 FROM Dual;");
			valid = st.executeQuery();
			if (valid.next()) {
				return;
			}
		} catch (SQLException e2) {
			System.out.println("Connection is idle or terminated. Reconnecting...");
		} finally {
			this.closeQuietly(valid);
		}

		long start = 0;
		long end = 0;

		try {
			start = System.currentTimeMillis();

			System.out.println("Attempting to establish a connection the MySQL server!");

			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database, username, password);

			end = System.currentTimeMillis();

			System.out.println("Connection to MySQL server established! (" + host + ":" + port + ")");
			System.out.println("Connection took " + ((end - start)) + "ms!");
		} catch (SQLException e) {
			System.out.println("Could not connect to MySQL server! because: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC Driver not found!");
		}
	}

	/**
	 * Executes the query provided using PreparedStatements without returning a ResultSet
	 *
	 * @param sql
	 * @return boolean
	 */
	public boolean execute(String sql) {
		this.refreshConnection();

		boolean st = false;
		try {
			PreparedStatement statement = connection.prepareStatement(sql);
			st = statement.execute();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return st;
	}

	/**
	 * Executes the query provided using PreparedStatements and returns a ResultSet object
	 *
	 * @param sql
	 * @return ResultSet
	 */
	public ResultSet executeQuery(String sql) {
		this.refreshConnection();

		PreparedStatement statement = null;
		ResultSet rs = null;

		try {
			statement = connection.prepareStatement(sql);
			rs = statement.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	/**
	 * Quietly closes the provided ResultSet
	 * 
	 * @param rs
	 * @exception SQLException
	 */
	public void closeQuietly(ResultSet rs) {
		PreparedStatement ps = null;

		try {
			ps = (PreparedStatement) rs.getStatement();
			rs.close();
			rs = null;
			ps.close();
			ps = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// Ignore... nothing we can do about this here
				}
			}

			if (ps != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// Ignore... nothing we can do about this here
				}
			}
		}
	}

	/**
	 * Executes update of provided query using PreparedStatements
	 *
	 * @param sql
	 * @return int
	 * @exception SQLException
	 */
	public int executeUpdate(String sql) {
		this.refreshConnection();

		int st = 0;
		try {
			PreparedStatement statement = connection.prepareStatement(sql);
			st = statement.executeUpdate();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return st;
	}

	/**
	 * Creates a table with the specified tablename and values in the database
	 *
	 * @param tablename
	 * @param values
	 * @exception SQLException
	 */
	public void createTable(String tablename, String[] values) {
		this.refreshConnection();

		StringBuilder stmt = new StringBuilder();

		stmt.append("CREATE TABLE IF NOT EXISTS " + tablename + "(");
		for (int i = 0; i < values.length; i++) {
			if (i == values.length) {
				stmt.append(values[i]);
			} else {
				stmt.append(values[i] + ",");
			}
		}
		stmt.append(");");

		try {
			PreparedStatement statement = connection.prepareStatement(stmt.toString());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Delete the table specified from the database
	 *
	 * @param tablename
	 * @exception SQLException
	 */
	public void deleteTable(String tablename) {
		this.refreshConnection();

		String sql = "DROP TABLE IF EXISTS " + tablename + ";";

		try {
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Deletes all data within the table specified
	 * 
	 * @param tablename
	 * @param values
	 */
	public void resetTable(String tablename, String[] values) {
		this.refreshConnection();

		String sql = "TRUNCATE TABLE " + tablename + ";";

		try {
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 *
	 * @param column
	 * @param value
	 */
	public void insertInto(String table, String[] columns, Object[] values) {
		this.refreshConnection();

		String statement = "INSERT INTO " + table;

		String c = "(";
		for (int i = 0; i < columns.length; i++)
		{
			if (i == columns.length - 1)
				c = c + columns;
			else
				c = c + columns + ",";
		}
		c = c + ")";

		String v = "(";
		for (int i = 0; i < values.length; i++)
		{

			if (i == columns.length - 1)
			{
				if (values[i] instanceof String)
					v = v + "'" + values + "'";
				else
					v = v + values;
			} else
			{
				if (values[i] instanceof String)
					v = v + "'" + values + "', ";
				else
					v = v + values + ", ";
			}
		}
		v = v + ")";

		statement = statement + c + " VALUES" + v + " ON DUPLICATE KEY UPDATE ";

		for (int i = 0; i < columns.length; i++)
		{
			statement = statement + columns + "=";

			if (i == columns.length - 1)
			{
				if (values[i] instanceof String)
					statement = statement + "'" + values + "'";
				else
					statement = statement + values;
			} else
			{
				if (values[i] instanceof String)
					statement = statement + "'" + values + "', ";
				else
					statement = statement + values + ", ";
			}

		}
		statement = statement + ";";

		this.executeUpdate(statement);
	}

	public void insertIntoWithoutPrimaryKey(String table, String[] columns, Object[] values) {
		this.refreshConnection();

		String statement = "INSERT INTO " + table;

		String c = "(";
		for (int i = 0; i < columns.length; i++)
		{
			if (i == columns.length - 1)
				c = c + columns;
			else
				c = c + columns + ",";
		}
		c = c + ")";

		String v = "(";
		for (int i = 0; i < values.length; i++)
		{

			if (i == columns.length - 1)
			{
				if (values[i] instanceof String)
					v = v + "'" + values + "'";
				else
					v = v + values;
			} else
			{
				if (values[i] instanceof String)
					v = v + "'" + values + "', ";
				else
					v = v + values + ", ";
			}
		}
		v = v + ")";

		statement = statement + c + " VALUES" + v + " ON DUPLICATE KEY UPDATE ";

		for (int i = 1; i < columns.length; i++)
		{
			statement = statement + columns + "=";

			if (i == columns.length - 1)
			{
				if (values[i] instanceof String)
					statement = statement + "'" + values + "'";
				else
					statement = statement + values;
			} else
			{
				if (values[i] instanceof String)
					statement = statement + "'" + values + "', ";
				else
					statement = statement + values + ", ";
			}

		}
		statement = statement + ";";

		this.executeUpdate(statement);
	}

	/**
	 * 
	 *
	 * @param column
	 * @param value
	 * @return ResultSet
	 */
	public ResultSet getRowByColumn(String table, String column, String value) {
		this.refreshConnection();

		ResultSet rs = this.executeQuery("SELECT * FROM " + table + " WHERE " + column + " = " + value);

		return rs;
	}

	/**
	 * Returns a String value of a certain column in the specified ResultSet
	 *
	 * @param table
	 * @param set
	 * @param column
	 * @return String
	 */
	public String getValueFromRow(String table, ResultSet set, String column) {
		this.refreshConnection();

		try
		{
			return set.getString(column);
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Returns the number of rows in the specified table
	 *
	 * @param table
	 * @return int
	 */
	public int getRowCount(String table) {
		this.refreshConnection();

		ResultSet rs = this.executeQuery("SELECT * FROM " + table);
		int count = 0;
		try
		{
			while (rs.next())
				count++;
		} catch (SQLException e)
		{
			e.printStackTrace();
		}

		return count;
	}

	/**
	 *
	 * @return Connection
	 */
	public Connection getConnection() {
		return connection;
	}

}