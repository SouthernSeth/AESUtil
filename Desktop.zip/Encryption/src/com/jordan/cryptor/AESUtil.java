package com.jordan.cryptor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class AESUtil {
	
	/**
	 * @author Jordan Wiggins (8/25/2017)
	 */
	
	
	/**
	 * Generate the AES 128bit encryption key using a password and salt.
	 * The password and salt combonation will always generate the same key, unless the password or salt is changed
	 * 
	 * @param password
	 *          :Password to encrypt with
	 * @param salt
	 *          :Random or determined salt for hashing
	 * @return SecretKey
	 * @throws NoSuchAlogrithmException
	 * @throws InvalidKeySpecException
	 */
	public static SecretKey generateAES(String password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeySpecException {
		char[] pass = password.toCharArray();

		SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
		KeySpec spec = new PBEKeySpec(pass, salt, 65536, 128);
		SecretKey tmp = factory.generateSecret(spec);
		SecretKey secret = new SecretKeySpec(tmp.getEncoded(), "AES");

		return secret;
	}

	/**
	 * Generates a random salt using a strong instance of SecureRandom with a randomly generated 16 byte seed
	 * 
	 * @throws NoSuchAlogrithmException
	 */
	public static byte[] getSalt() throws NoSuchAlgorithmException {
		SecureRandom random = SecureRandom.getInstanceStrong();
		byte[] seed = random.generateSeed(16);
		random.setSeed(seed);

		byte[] salt = new byte[8];
		random.nextBytes(salt);
		return salt;
	}

	/**
	 * This method will only work for an already encrypted file
	 * This method pulls the salt from an encrypted file and returns it in a byte array
	 * 
	 * @param encryptedFile
	 *          :Encrypted file to pull the salt from
	 * @return byte[]
	 * @throws IOException
	 */
	public static byte[] getSaltFromFile(File encryptedFile) throws IOException {
		StringBuilder builder = new StringBuilder();

		BufferedReader br = new BufferedReader(new FileReader(encryptedFile));
		String str = null;

		while ((str = br.readLine()) != null) {
			String newStr = new String(Base64.getDecoder().decode(str));
			builder.append(newStr + "\n");
		}

		br.close();

		System.out.println(builder.toString());

		StringBuilder salt = new StringBuilder();
		boolean read = false;
		for (int i = 0;i<builder.length();i++) {

			String substring = null;
			String substring2 = null;
			String substring3 = null;
			String substring4 = null;
			String substring5 = null;
			
			try {
				substring = builder.substring(i, i+1);
				substring2 = builder.substring(i+1, i+2);
				substring3 = builder.substring(i+2, i+3);
				substring4 = builder.substring(i+3, i+4);
				substring5 = builder.substring(i+4, i+5);
			} catch (StringIndexOutOfBoundsException e) {
				//Skip
			}

			if (substring.equalsIgnoreCase("{") && substring2.equalsIgnoreCase("S") && substring3.equalsIgnoreCase("A") && substring4.equalsIgnoreCase("L") && substring5.equalsIgnoreCase("T")) {
				read = true;
			} else if (substring.equalsIgnoreCase("}") && read) {
				salt.append(substring);
				break;
			}

			if (read) {
				salt.append(substring);
			}
		}

		String salt_unformatted = salt.toString();

		String salt_formatted = salt_unformatted.replace("{SALT:", "");
		salt_formatted = salt_formatted.replace("}", "");

		byte[] value = Base64.getDecoder().decode(salt_formatted);

		return value;
	}

	/**
	 * This method will only work for an already encrypted file
	 * This method pulls the iv from an encrypted file and returns it in a byte array
	 * 
	 * @param encryptedFile
	 *          :Encrypted file to pull the salt from
	 * @return byte[]
	 * @throws IOException
	 */
	public static byte[] getIVFromFile(File encryptedFile) throws IOException {
		StringBuilder builder = new StringBuilder();

		BufferedReader br = new BufferedReader(new FileReader(encryptedFile));
		String str = null;

		while ((str = br.readLine()) != null) {
			String newStr = new String(Base64.getDecoder().decode(str));
			builder.append(newStr + "\n");
		}

		br.close();

		StringBuilder iv = new StringBuilder();
		boolean read = false;
		for (int i = 0;i<builder.length();i++) {
			String substring = null;
			String substring2 = null;
			String substring3 = null;
			
			try {
				substring = builder.substring(i, i+1);
				substring2 = builder.substring(i+1, i+2);
				substring3 = builder.substring(i+2, i+3);
			} catch (StringIndexOutOfBoundsException e) {
				//Skip
			}

			if (substring.equalsIgnoreCase("{") && substring2.equalsIgnoreCase("I") && substring3.equalsIgnoreCase("V")) {
				read = true;
			} else if (substring.equalsIgnoreCase("}") && read) {
				iv.append(substring);
				break;
			}

			if (read) {
				iv.append(substring);
			}
		}

		String iv_unformatted = iv.toString();

		String iv_formatted = iv_unformatted.replace("{IV:", "");
		iv_formatted = iv_formatted.replace("}", "");

		byte[] value = Base64.getDecoder().decode(iv_formatted);

		return value;
	}

	/**
	 * This method will only work for an already encrypted file
	 * This method should only be called in the decrypt method
	 * This method takes the encrypted file and removes the salt and iv from the file
	 * 
	 * @param inputFile
	 *          :Encrypted file to pull the salt from
	 * @param salt
	 * 			:The salt that needs to be removed from the file
	 * @param iv
	 * 			:The iv that needs to be removed from the file
	 * @throws IOException
	 */
	private static void prepareFileForDecrypt(File inputFile, byte[] salt, byte[] iv) throws IOException {
		File temp = new File(inputFile.getAbsolutePath() + ".tmp");

		if (temp.exists()) {
			temp.delete();
		}

		temp.createNewFile();

		String ivf = "{IV:" + Base64.getEncoder().encodeToString(iv) + "}";
		String saltf = "{SALT:" + Base64.getEncoder().encodeToString(salt) + "}";

		BufferedReader br = new BufferedReader(new FileReader(inputFile));
		BufferedWriter bw = new BufferedWriter(new FileWriter(temp));
		String str = null;

		while ((str = br.readLine()) != null) {
			String form = new String(Base64.getDecoder().decode(str));
			String trimmedStr = form.trim();
			if (trimmedStr.equals(ivf) || trimmedStr.equals(saltf)) continue;
			bw.write(str);
			bw.newLine();
		}

		br.close();
		bw.flush();
		bw.close();

		inputFile.delete();
		temp.renameTo(new File(temp.getAbsolutePath().replace(".tmp", "")));
	}

	/**
	 * This method will encrypt the file you input using the supplied AES key
	 * The salt and iv are stored inside the encrypted file in Base64 format for decrypting later
	 * The salt is explicity defined since you can't pull the salt from the AES key
	 * 
	 * @param inputFile
	 *          :Un-encrypted file to encrypt
	 * @param aes
	 * 			:AES key to encrypt the data with
	 * @param salt
	 * 			:Salt of the AES key provided
	 * @throws IOException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidParameterSpecException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public static void encryptFile(File inputFile, SecretKey aes, byte[] salt) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidParameterSpecException, IllegalBlockSizeException, BadPaddingException {
		File file = new File(inputFile.getParentFile().getAbsolutePath() + "\\" + inputFile.getName() + ".crypto");

		if (file.exists()) {
			file.delete();
		}

		file.createNewFile();

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, aes);
		AlgorithmParameters params = cipher.getParameters();
		byte[] iv = params.getParameterSpec(IvParameterSpec.class).getIV();

		FileInputStream fis = new FileInputStream(inputFile);

		BufferedWriter bw = new BufferedWriter(new FileWriter(file));

		byte[] input = new byte[64];
		int bytesRead;

		while ((bytesRead = fis.read(input)) != -1) {
			byte[] output = cipher.update(input, 0, bytesRead);
			if (output != null) {
				bw.write(Base64.getEncoder().encodeToString(output) + System.getProperty("line.separator"));
			}
		}

		byte[] output = cipher.doFinal();
		if (output != null) {
			bw.write(Base64.getEncoder().encodeToString(output) + System.getProperty("line.separator"));
		}

		String ive = Base64.getEncoder().encodeToString(new String("{IV:" + Base64.getEncoder().encodeToString(iv) + "}").getBytes());
		String salte = Base64.getEncoder().encodeToString(new String("{SALT:" + Base64.getEncoder().encodeToString(salt) + "}").getBytes());

		bw.write(ive);
		bw.newLine();
		bw.write(salte);

		bw.flush();
		bw.close();
		fis.close();

		inputFile.delete();
	}

	/**
	 * This method will decrypt the encrypted file defined using a password
	 * If the password is not the same password used when the file was encrypted you will not be able to decrypt the file
	 * 
	 * @param inputFile
	 *          :Encrypted file that you want to decrypt
	 * @param password
	 * 			:Password that the file was encrypted with
	 * @throws IOException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidParameterSpecException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public static void decryptFile(File inputFile, String password) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidParameterSpecException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		File file = new File(inputFile.getParentFile().getAbsolutePath() + "\\" + inputFile.getName().replace(".crypto", ""));

		if (file.exists()) {
			file.delete();
		}

		file.createNewFile();

		byte[] salt = getSaltFromFile(inputFile);
		byte[] iv = getIVFromFile(inputFile);

		SecretKey key = null;
		try {
			key = generateAES(password, salt);
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
		}

		prepareFileForDecrypt(inputFile, salt, iv);

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));

		FileOutputStream fos = new FileOutputStream(file);
		BufferedReader br = new BufferedReader(new FileReader(inputFile));
		String str = null;

		while ((str = br.readLine()) != null) {
			byte[] encryptedText = Base64.getDecoder().decode(str);
			byte[] output = cipher.update(encryptedText);
			if (output != null) {
				fos.write(output);
			}
		}

		byte[] output = cipher.doFinal();
		if (output != null) {
			fos.write(output);
		}

		br.close();
		fos.flush();
		fos.close();

		inputFile.delete();
	}

}
