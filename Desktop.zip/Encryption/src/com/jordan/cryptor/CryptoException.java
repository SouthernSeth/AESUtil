package com.jordan.cryptor;

public class CryptoException extends Exception {
	
	/**
	 * @author Jordan Wiggins
	 */
	private static final long serialVersionUID = 1L;

	public CryptoException() {
    }
 
    public CryptoException(String message, Throwable throwable) {
        super(message, throwable);
    }

}
