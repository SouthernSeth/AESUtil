﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Data.SQLite;

namespace ApexTimeTracker
{
    public partial class Form1 : Form
    {

        private Thread refreshDateThread;

        public Form1()
        {
            InitializeComponent();
        }

        //Some variables to load before we show the form
        private void Form1_Load(object sender, EventArgs e)
        {
            refreshDateThread = new Thread(new ThreadStart(refreshTime));
            refreshDateThread.Start();

            Text = "Apex Time Tracker - " + Environment.UserName;

            var sqlite = Sqlite.Instance();
            sqlite.InitializeTable();
            sqlite.InitializeSettings();

            Timecard timecard = sqlite.GetIncompleteTimecard();
            if (timecard != null)
            {
                Sqlite.CurrentTimecard = timecard.ID;

                if (!IsDateNull(timecard.ClockInTime))
                {
                    textBox1.Text = timecard.ClockInTime.ToString();
                    clockIn.Enabled = false;
                    clockOut.Enabled = true;
                    toLunch.Enabled = true;
                }

                if (!IsDateNull(timecard.ToLunchTime))
                {
                    textBox2.Text = timecard.ToLunchTime.ToString();
                    toLunch.Enabled = false;
                    returnLunch.Enabled = true;
                }

                if (!IsDateNull(timecard.ReturnLunchTime))
                {
                    textBox3.Text = timecard.ReturnLunchTime.ToString();
                    returnLunch.Enabled = false;
                }

                if (!IsDateNull(timecard.ClockOutTime))
                {
                    textBox4.Text = timecard.ClockOutTime.ToString();
                    clockOut.Enabled = false;
                }
            }
        }

        //Just some cleanup. If we dont close the thread before shutting down the application, the application will never close completely.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (refreshDateThread != null && refreshDateThread.IsAlive)
            {
                refreshDateThread.Abort();
            }
        }

        //Clock In
        private void button1_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;

            var sqlite = Sqlite.Instance();
            int id = sqlite.CreateTimecard(now);

            Sqlite.CurrentTimecard = id;

            textBox1.Text = now.ToString();

            clockIn.Enabled = false;
            toLunch.Enabled = true;
            clockOut.Enabled = true;
        }

        //To Lunch
        private void button2_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;

            var sqlite = Sqlite.Instance();

            Timecard timecard = sqlite.GetTimecard(Sqlite.CurrentTimecard);
            timecard.ToLunchTime = now;
            sqlite.UpdateTimecard(timecard);

            textBox2.Text = now.ToString();

            toLunch.Enabled = false;
            returnLunch.Enabled = true;
        }

        //Return Lunch
        private void button3_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;

            var sqlite = Sqlite.Instance();

            Timecard timecard = sqlite.GetTimecard(Sqlite.CurrentTimecard);
            timecard.ReturnLunchTime = now;
            sqlite.UpdateTimecard(timecard);

            textBox3.Text = now.ToString();

            returnLunch.Enabled = false;
        }
       
        //Clock Out
        private void button4_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;

            var sqlite = Sqlite.Instance();

            Timecard timecard = sqlite.GetTimecard(Sqlite.CurrentTimecard);
            timecard.ClockOutTime = now;
            sqlite.UpdateTimecard(timecard);

            textBox4.Text = now.ToString();

            clockOut.Enabled = false;
        }

        //View Timesheet
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.SetDesktopLocation(this.DesktopLocation.X - 200, this.DesktopLocation.Y - 50);
            form2.Show();
        }

        //File > Exit
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (refreshDateThread != null && refreshDateThread.IsAlive)
            {
                refreshDateThread.Abort();
            }

            Application.Exit();
        }

        //File > Settings
        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.SetDesktopLocation(this.DesktopLocation.X + 55, this.DesktopLocation.Y + 15);
            settings.Show();
        }

        //Timer
        private void toolStripButton2_Click(object sender, EventArgs e)
        {

        }

        //Method to update the status label in the status bar
        private void refreshTime()
        {
            while (true)
            {
                if (refreshDateThread.IsAlive)
                {
                    DateTime date = DateTime.Now;
                    toolStripStatusLabel1.Text = date.ToString();
                    Thread.Sleep(1);
                }
            }
        }

        private void loadTimecardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 loadTimecard = new Form3(this);
            loadTimecard.Show();
        }

        private bool IsDateNull(DateTime date)
        {
            if (date.Year == 0001)
            {
                return true;
            }

            return false;
        }

        private void deleteTimesheetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to delete all of your saved time?", "Delete Timesheet?", MessageBoxButtons.YesNo);

            if (dr == DialogResult.Yes)
            {
                Sqlite.Instance().DeleteAllTimecards();

                clockIn.Enabled = true;
                toLunch.Enabled = false;
                returnLunch.Enabled = false;
                clockOut.Enabled = false;

                textBox1.Text = "N/A";
                textBox2.Text = "N/A";
                textBox3.Text = "N/A";
                textBox4.Text = "N/A";
            }
        }

        //FIX THIS
        private void newTimecardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "N/A" && textBox4.Text != "N/A")
            {
            
            }
        }
    }
}
