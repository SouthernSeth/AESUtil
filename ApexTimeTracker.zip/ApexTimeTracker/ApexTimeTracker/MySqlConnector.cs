﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace ApexTimeTracker
{
    class MySqlConnector
    {

        private MySqlConnector()
        { 
        }

        private string hostname = string.Empty;
        public string HostName
        {
            get { return hostname; }
            set { hostname = value; }
        }

        private string port = string.Empty;
        public string Port
        {
            get { return port; }
            set { port = value; }
        }

        private string databaseName = string.Empty;
        public string DatabaseName
        {
            get { return databaseName; }
            set { databaseName = value; }
        }

        private string username = string.Empty;
        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        private string password = string.Empty;
        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        private MySqlConnection connection = null;
        public MySqlConnection Connection
        {
            get { return connection; }
        }

        private static MySqlConnector _instance;
        public static MySqlConnector Instance()
        {
            if (_instance == null)
            {
                _instance = new MySqlConnector();
            }

            return _instance;
        }

        public bool isConnected()
        {
            if (Connection == null || Connection.State == ConnectionState.Closed)
            {
                if (String.IsNullOrEmpty(databaseName) || String.IsNullOrEmpty(hostname) || String.IsNullOrEmpty(username) || String.IsNullOrEmpty(password))
                {
                    return false;
                }

                MySqlConnectionStringBuilder conn_string = new MySqlConnectionStringBuilder();
                conn_string.Server = hostname;
                conn_string.UserID = username;
                conn_string.Password = password;
                conn_string.Database = databaseName;

                string connectionString = string.Format(conn_string.ToString());

                connection = new MySqlConnection(connectionString);

                try 
                { 
                    connection.Open();
                }
                catch (MySqlException ex)
                {
                    Console.WriteLine("");
                    Console.WriteLine("---------- ERROR ----------");
                    Console.WriteLine("Error: " + ex.StackTrace);
                    Console.WriteLine("Message: " + ex.Message);
                    Console.WriteLine("Error Code: " + ex.ErrorCode);
                    Console.WriteLine("Help Link: " + (String.IsNullOrEmpty(ex.HelpLink) ? "N/A" : ex.HelpLink));
                    Console.WriteLine("---------- ERROR ----------");
                    Console.WriteLine("");
                    return false;
                }
                
                return true;
            }

            return false;
        }

        public void Close()
        { 
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();            
            }
        }

    }
}
