﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace ApexTimeTracker
{
    public partial class Form3 : Form
    {

        private Form parent;

        public Form3(Form parent)
        {
            this.parent = parent;
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            var sqlite = Sqlite.Instance();
            ArrayList timecards = sqlite.GetAllTimecards();

            if (timecards.Count > 0)
            {
                for (int i = 0; i < timecards.Count; i++)
                {
                    Timecard timecard = (Timecard)timecards[i];
                    if (timecard.ClockInTime.Date.CompareTo(timecard.ClockOutTime.Date) == -1)
                    {
                        listBox1.Items.Add("#" + timecard.ID + " : " + timecard.ClockInTime.Month + "/" + timecard.ClockInTime.Day + "/" + timecard.ClockInTime.Year + " : Overnight Shift");
                    }
                    else
                    {
                        listBox1.Items.Add("#" + timecard.ID + " : " + timecard.ClockInTime.Month + "/" + timecard.ClockInTime.Day + "/" + timecard.ClockInTime.Year);
                    }
                }
            }
            else 
            {
                listBox1.Items.Add("NO TIMECARDS SAVED");
            }
        }
    }
}
