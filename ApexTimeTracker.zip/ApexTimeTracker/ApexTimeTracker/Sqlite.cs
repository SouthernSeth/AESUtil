﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SQLite;
using System.Data;
using System.IO;
using System.Collections;

namespace ApexTimeTracker
{
    class Sqlite
    {

        private static string folder;
        private static string file;

        private Sqlite()
        {
            folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ApexTimeTracker";
            file = folder + "\\" + "apextimetracker.sqlite";

            Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ApexTimeTracker");
        }

        public static string FolderPath
        {
            get { return folder; }
        }

        public static string FilePath
        {
            get { return file; }
        }

        private SQLiteConnection connection = null;
        public SQLiteConnection Connection
        {
            get { return connection; }
        }

        private static Sqlite _instance = null;
        public static Sqlite Instance()
        {
            if (_instance == null)
            {
                _instance = new Sqlite();
            }

            return _instance;
        }

        private static int currentTimecard = -1;
        public static int CurrentTimecard
        {
            get { return currentTimecard; }
            set { currentTimecard = value; }
        }

        public bool Open()
        {
            if (Connection == null)
            {
                connection = new SQLiteConnection("Data Source=" + file + "; Version=3; ");
                connection.Open();
            } 
            else if (Connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }

            return true;
        }

        public void Close()
        {
            connection.Close();
        }

        public void Test()
        {
            if (Open())
            {
                for (int i = 0; i < 10; i++)
                {
                    string sql = "INSERT INTO timecards (clockin, tolunch, returnlunch, clockout) VALUES (?,?,?,?)";
                    SQLiteCommand command = new SQLiteCommand(sql, Connection);
                    command.Parameters.Add(new SQLiteParameter("clockin", DateTime.Now));
                    command.Parameters.Add(new SQLiteParameter("tolunch", DateTime.Now));
                    command.Parameters.Add(new SQLiteParameter("returnlunch", DateTime.Now));
                    command.Parameters.Add(new SQLiteParameter("clockout", DateTime.Now));
                    command.ExecuteNonQuery();
                }

                Close();
            }
        }

        public string GetSetting(string key)
        {
            if (Open())
            {
                string sql = "SELECT value FROM settings where key = ?";

                SQLiteCommand command = new SQLiteCommand(sql, Connection);
                command.Parameters.Add(new SQLiteParameter("key", key));
                var reader = command.ExecuteReader();

                if (reader.Read())
                {
                    return reader.GetString(0);
                }

                Close();
            }

            return null;
        }

        public void InitializeTable()
        {
            if (Open())
            {
                string sql = "CREATE TABLE IF NOT EXISTS timecards (id integer primary key, clockin date, tolunch date, returnlunch date, clockout date)";
                string sql2 = "CREATE TABLE IF NOT EXISTS settings (key string, value string)";

                SQLiteCommand command = new SQLiteCommand(sql, Connection);
                command.ExecuteNonQuery();

                command = new SQLiteCommand(sql2, Connection);
                command.ExecuteNonQuery();

                Close();
            }
        }

        public void InitializeSettings()
        {
            string[][] defaultSettings = new string[2][];

            defaultSettings[0] = new string[] { "email", "first.m.last@email.com" };
            defaultSettings[1] = new string[] { "last_day_of_work_week", "friday" };

            if (Open())
            {
                string sql = "INSERT INTO settings (key, value) VALUES (?,?)";

                for (int i = 0; i < defaultSettings.Length; i++)
                {
                    string key = defaultSettings[i][0];
                    string value = defaultSettings[i][1];

                    SQLiteCommand command = new SQLiteCommand(sql, Connection);
                    command.Parameters.Add(new SQLiteParameter("key", key));
                    command.Parameters.Add(new SQLiteParameter("value", value));
                    command.ExecuteNonQuery();
                }

                Close();
            }
        }

        public Dictionary<string, string> GetSettings()
        {
            Dictionary<string, string> tmp = new Dictionary<string, string>();

            if (Open())
            {
                string sql = "SELECT * FROM settings";

                SQLiteCommand command = new SQLiteCommand(sql, Connection);
                var reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string key = reader.GetString(0);
                        string value = reader.GetString(1);
                        tmp[key] = value;  
                    }
                }

            }

            return tmp;
        }

        public Timecard GetIncompleteTimecard()
        {
            if (Open())
            {
                string sql = "SELECT * FROM timecards";

                SQLiteCommand command = new SQLiteCommand(sql, Connection);
                var reader = command.ExecuteReader();

                Timecard timecard = new Timecard();

                if (reader.HasRows)
                {
                    while(reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        timecard.ID = id;

                        if (reader.IsDBNull(4))
                        {
                            DateTime clockIn = reader.GetDateTime(1);
                            timecard.ClockInTime = clockIn;

                            if (!reader.IsDBNull(2))
                            {
                                DateTime toLunch = reader.GetDateTime(2);
                                timecard.ToLunchTime = toLunch;
                            }

                            if (!reader.IsDBNull(3))
                            {
                                DateTime returnLunch = reader.GetDateTime(3);
                                timecard.ReturnLunchTime = returnLunch;
                            }

                            break;
                        } 
                        else if (reader.GetDateTime(4).Year == 0001)
                        {
                            DateTime clockIn = reader.GetDateTime(1);
                            timecard.ClockInTime = clockIn;

                            if (!reader.IsDBNull(2))
                            {
                                DateTime toLunch = reader.GetDateTime(2);
                                timecard.ToLunchTime = toLunch;
                            }

                            if (!reader.IsDBNull(3))
                            {
                                DateTime returnLunch = reader.GetDateTime(3);
                                timecard.ReturnLunchTime = returnLunch;
                            }

                            break;
                        }
                    }
                }

                Close();
                return timecard;
            }

            Close();
            return null;
        }

        //THIS NEEDS TO BE FIXED
        public Timecard GetLatestTimecard()
        {
            if (Open())
            {
                string sql = "SELECT BOTTOM FROM timecards";

                SQLiteCommand command = new SQLiteCommand(sql, Connection);
                var reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        DateTime clockIn = reader.GetDateTime(1);
                        DateTime toLunch = reader.GetDateTime(2);
                        DateTime returnLunch = reader.GetDateTime(3);
                        DateTime clockOut = reader.GetDateTime(4);

                        Timecard timecard = new Timecard();
                        timecard.ID = id;
                        timecard.ClockInTime = clockIn;
                        timecard.ToLunchTime = toLunch;
                        timecard.ReturnLunchTime = returnLunch;
                        timecard.ClockOutTime = clockOut;

                        Close();
                        return timecard;
                    }
                }
            }

            Close();
            return null;
        }

        public ArrayList GetAllTimecards()
        {
            ArrayList timecards = new ArrayList();

            if (Open())
            {
                string sql = "SELECT * FROM timecards";

                SQLiteCommand command = new SQLiteCommand(sql, Connection);
                var reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Timecard timecard = new Timecard();

                        int id = reader.GetInt32(0);
                        timecard.ID = id;

                        if (!reader.IsDBNull(1))
                        {
                            DateTime time = reader.GetDateTime(1);
                            timecard.ClockInTime = time;
                        }

                        if (!reader.IsDBNull(2))
                        {
                            DateTime time = reader.GetDateTime(2);
                            timecard.ToLunchTime = time;
                        }

                        if (!reader.IsDBNull(3))
                        {
                            DateTime time = reader.GetDateTime(3);
                            timecard.ReturnLunchTime = time;
                        }

                        if (!reader.IsDBNull(4))
                        {
                            DateTime time = reader.GetDateTime(4);
                            timecard.ClockOutTime = time;
                        }

                        timecards.Add(timecard);
                    }
                }

                Close();
                return timecards;
            }

            return null;
        }

        public void DeleteAllTimecards()
        {
            string[] commands = new string[] { "DROP TABLE timecards", "CREATE TABLE IF NOT EXISTS timecards (id integer primary key, clockin date, tolunch date, returnlunch date, clockout date)" };

            if (Open())
            {
                for (int i = 0; i < commands.Length; i++)
                {
                    string sql = commands[i];

                    SQLiteCommand command = new SQLiteCommand(sql, Connection);
                    command.ExecuteNonQuery();
                }

                Close();
            }
        }

        public int CreateTimecard(DateTime clockin)
        {
            if (Open())
            {
                string sql = "SELECT * FROM timecards";
                SQLiteCommand rowCount = new SQLiteCommand(sql, Connection);
                var reader = rowCount.ExecuteReader();
                int index = 0;

                while (reader.Read())
                {
                    index++;
                }

                index += 1;

                string sql2 = "INSERT INTO timecards (clockin) VALUES (?)";
                SQLiteCommand command = new SQLiteCommand(sql2, Connection);
                command.Parameters.Add(new SQLiteParameter("clockin", clockin));
                command.ExecuteNonQuery();

                Close();
                return index;
            }

            return 0;
        }

        public void UpdateTimecard(Timecard timecard)
        { 
            if (Open())
            {
                string sql = "UPDATE timecards SET clockin = ?, tolunch = ?, returnlunch = ?, clockout = ? WHERE id = ?";

                SQLiteCommand command = new SQLiteCommand(sql, Connection);
                command.Parameters.Add(new SQLiteParameter("clockin", timecard.ClockInTime));
                command.Parameters.Add(new SQLiteParameter("tolunch", timecard.ToLunchTime));
                command.Parameters.Add(new SQLiteParameter("returnlunch", timecard.ReturnLunchTime));
                command.Parameters.Add(new SQLiteParameter("clockout", timecard.ClockOutTime));
                command.Parameters.Add(new SQLiteParameter("id", timecard.ID));

                command.ExecuteNonQuery();

                Close();
            }
        }

        public Timecard GetTimecard(int id)
        { 
            if (Open())
            {
                string sql = "SELECT * FROM timecards WHERE id = ?";

                SQLiteCommand command = new SQLiteCommand(sql, Connection);
                command.Parameters.Add(new SQLiteParameter("id", id));

                var reader = command.ExecuteReader();

                if (reader.Read())
                {
                    Timecard timecard = new Timecard();
                    timecard.ID = id;

                    DateTime clockIn = reader.GetDateTime(1);
                    timecard.ClockInTime = clockIn;

                    if (!reader.IsDBNull(2))
                    {
                        DateTime toLunch = reader.GetDateTime(2);
                        timecard.ToLunchTime = toLunch;
                    }

                    if (!reader.IsDBNull(3))
                    {
                        DateTime returnLunch = reader.GetDateTime(3);
                        timecard.ReturnLunchTime = returnLunch;
                    }

                    if (!reader.IsDBNull(4))
                    {
                        DateTime clockOut = reader.GetDateTime(4);
                        timecard.ClockOutTime = clockOut;
                    }

                    Close();
                    return timecard;
                }
            }

            return null;
        }
    }
}
