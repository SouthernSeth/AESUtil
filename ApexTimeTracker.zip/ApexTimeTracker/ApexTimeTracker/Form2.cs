﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Collections;

namespace ApexTimeTracker
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            var sqlite = Sqlite.Instance();
            ArrayList timecards = sqlite.GetAllTimecards();

            for (int i = 0; i < timecards.Count; i++)
            {
                Timecard timecard = (Timecard)timecards[i];
                dataGridView1.Rows.Add(timecard.ID, timecard.ClockInTime.ToString(), IsDateNull(timecard.ToLunchTime) ? "N/A" : timecard.ToLunchTime.ToString(), IsDateNull(timecard.ReturnLunchTime) ? "N/A" : timecard.ReturnLunchTime.ToString(), IsDateNull(timecard.ClockOutTime) ? "N/A" : timecard.ClockOutTime.ToString());
            }
        }

        private bool IsDateNull(DateTime date)
        { 
            if (date.Year == 0001)
            {
                return true;
            }

            return false;
        }
    }
}
