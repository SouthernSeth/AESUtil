﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ApexTimeTracker
{
    class Timecard
    {

        private int id;

        private DateTime clockIn;
        private DateTime toLunch;
        private DateTime fromLunch;
        private DateTime clockOut;

        public Timecard(int id, DateTime clockIn, DateTime toLunch, DateTime fromLunch, DateTime clockOut)
        {
            this.id = id;
            this.clockIn = clockIn;
            this.toLunch = toLunch;
            this.fromLunch = fromLunch;
            this.clockOut = clockOut;
        }

        public Timecard()
        { 
        }

        public double CalculateHours()
        {
            return 0.0;
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public DateTime ClockInTime
        {
            get { return clockIn; }
            set { clockIn = value; }
        }

        public DateTime ToLunchTime
        {
            get { return toLunch; }
            set { toLunch = value; }
        }

        public DateTime ReturnLunchTime
        {
            get { return fromLunch; }
            set { fromLunch = value; }
        }

        public DateTime ClockOutTime
        {
            get { return clockOut; }
            set { clockOut = value; }
        }
    }
}
