﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ApexTimeTracker
{
    public partial class Settings : Form
    {
        public Settings()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Settings_Load(object sender, EventArgs e)
        {
            var sqlite = Sqlite.Instance();
            Dictionary<string, string> settings = sqlite.GetSettings();

            string value = settings["email"];
            string value2 = settings["last_day_of_work_week"];

            textBox1.Text = value;
            comboBox1.SelectedText = value2.ToUpper();
        }
    }
}
