﻿namespace ApexTimeTracker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.newTimecardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customTimecardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.loadTimecardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteTimecardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editTimecardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.emailTimesheetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteTimesheetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.clockOut = new System.Windows.Forms.Button();
            this.returnLunch = new System.Windows.Forms.Button();
            this.toLunch = new System.Windows.Forms.Button();
            this.clockIn = new System.Windows.Forms.Button();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripSeparator6,
            this.toolStripButton1,
            this.toolStripSeparator5,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(394, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newTimecardToolStripMenuItem,
            this.customTimecardToolStripMenuItem,
            this.toolStripSeparator1,
            this.loadTimecardToolStripMenuItem,
            this.deleteTimecardToolStripMenuItem,
            this.editTimecardToolStripMenuItem,
            this.toolStripSeparator2,
            this.emailTimesheetToolStripMenuItem,
            this.deleteTimesheetToolStripMenuItem,
            this.toolStripSeparator3,
            this.settingsToolStripMenuItem,
            this.toolStripSeparator4,
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(38, 22);
            this.toolStripDropDownButton1.Text = "File";
            // 
            // newTimecardToolStripMenuItem
            // 
            this.newTimecardToolStripMenuItem.Name = "newTimecardToolStripMenuItem";
            this.newTimecardToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.newTimecardToolStripMenuItem.Text = "New Timecard";
            this.newTimecardToolStripMenuItem.Click += new System.EventHandler(this.newTimecardToolStripMenuItem_Click);
            // 
            // customTimecardToolStripMenuItem
            // 
            this.customTimecardToolStripMenuItem.Name = "customTimecardToolStripMenuItem";
            this.customTimecardToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.customTimecardToolStripMenuItem.Text = "Manually Add Timecard";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(198, 6);
            // 
            // loadTimecardToolStripMenuItem
            // 
            this.loadTimecardToolStripMenuItem.Name = "loadTimecardToolStripMenuItem";
            this.loadTimecardToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.loadTimecardToolStripMenuItem.Text = "Load Timecard";
            this.loadTimecardToolStripMenuItem.Click += new System.EventHandler(this.loadTimecardToolStripMenuItem_Click);
            // 
            // deleteTimecardToolStripMenuItem
            // 
            this.deleteTimecardToolStripMenuItem.Name = "deleteTimecardToolStripMenuItem";
            this.deleteTimecardToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.deleteTimecardToolStripMenuItem.Text = "Delete Timecard";
            // 
            // editTimecardToolStripMenuItem
            // 
            this.editTimecardToolStripMenuItem.Name = "editTimecardToolStripMenuItem";
            this.editTimecardToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.editTimecardToolStripMenuItem.Text = "Edit Timecard";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(198, 6);
            // 
            // emailTimesheetToolStripMenuItem
            // 
            this.emailTimesheetToolStripMenuItem.Name = "emailTimesheetToolStripMenuItem";
            this.emailTimesheetToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.emailTimesheetToolStripMenuItem.Text = "Email Timesheet";
            // 
            // deleteTimesheetToolStripMenuItem
            // 
            this.deleteTimesheetToolStripMenuItem.Name = "deleteTimesheetToolStripMenuItem";
            this.deleteTimesheetToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.deleteTimesheetToolStripMenuItem.Text = "Delete Timesheet";
            this.deleteTimesheetToolStripMenuItem.Click += new System.EventHandler(this.deleteTimesheetToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(198, 6);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.settingsToolStripMenuItem.Text = "Settings...";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(198, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(94, 22);
            this.toolStripButton1.Text = "View Timesheet";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(42, 22);
            this.toolStripButton2.Text = "Timer";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 199);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(394, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.clockOut);
            this.panel1.Controls.Add(this.returnLunch);
            this.panel1.Controls.Add(this.toLunch);
            this.panel1.Controls.Add(this.clockIn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(394, 174);
            this.panel1.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox4.Enabled = false;
            this.textBox4.Location = new System.Drawing.Point(134, 136);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(248, 20);
            this.textBox4.TabIndex = 8;
            this.textBox4.Text = "N/A";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox3.Enabled = false;
            this.textBox3.Location = new System.Drawing.Point(134, 97);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(248, 20);
            this.textBox3.TabIndex = 7;
            this.textBox3.Text = "N/A";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(134, 58);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(248, 20);
            this.textBox2.TabIndex = 6;
            this.textBox2.Text = "N/A";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(134, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(248, 20);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "N/A";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // clockOut
            // 
            this.clockOut.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.clockOut.Enabled = false;
            this.clockOut.Location = new System.Drawing.Point(12, 134);
            this.clockOut.Name = "clockOut";
            this.clockOut.Size = new System.Drawing.Size(92, 23);
            this.clockOut.TabIndex = 4;
            this.clockOut.Text = "Clock Out";
            this.clockOut.UseVisualStyleBackColor = true;
            this.clockOut.Click += new System.EventHandler(this.button4_Click);
            // 
            // returnLunch
            // 
            this.returnLunch.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.returnLunch.Enabled = false;
            this.returnLunch.Location = new System.Drawing.Point(12, 95);
            this.returnLunch.Name = "returnLunch";
            this.returnLunch.Size = new System.Drawing.Size(92, 23);
            this.returnLunch.TabIndex = 3;
            this.returnLunch.Text = "Return Lunch";
            this.returnLunch.UseVisualStyleBackColor = true;
            this.returnLunch.Click += new System.EventHandler(this.button3_Click);
            // 
            // toLunch
            // 
            this.toLunch.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.toLunch.Enabled = false;
            this.toLunch.Location = new System.Drawing.Point(12, 56);
            this.toLunch.Name = "toLunch";
            this.toLunch.Size = new System.Drawing.Size(92, 23);
            this.toLunch.TabIndex = 2;
            this.toLunch.Text = "To Lunch";
            this.toLunch.UseVisualStyleBackColor = true;
            this.toLunch.Click += new System.EventHandler(this.button2_Click);
            // 
            // clockIn
            // 
            this.clockIn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.clockIn.Location = new System.Drawing.Point(12, 17);
            this.clockIn.Name = "clockIn";
            this.clockIn.Size = new System.Drawing.Size(92, 23);
            this.clockIn.TabIndex = 1;
            this.clockIn.Text = "Clock In";
            this.clockIn.UseVisualStyleBackColor = true;
            this.clockIn.Click += new System.EventHandler(this.button1_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 221);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(400, 250);
            this.MinimumSize = new System.Drawing.Size(400, 250);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Apex Time Tracker";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button clockOut;
        private System.Windows.Forms.Button returnLunch;
        private System.Windows.Forms.Button toLunch;
        private System.Windows.Forms.Button clockIn;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem newTimecardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customTimecardToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem loadTimecardToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem deleteTimecardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editTimecardToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem emailTimesheetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteTimesheetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    }
}

