package me.southernseth.litecryptor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Base64;

import org.json.JSONObject;

import me.southernseth.litecryptor.util.LCCertificate;

public class CertificateManager {

	private ArrayList<LCCertificate> loadedCerts = new ArrayList<LCCertificate>();

	public CertificateManager() throws IOException {
		String certStore = LiteCryptor.certStorePath();

		File f = new File(certStore + "\\certificates.json");
		if (!f.exists()) {
			f.getParentFile().mkdirs();
			f.createNewFile();
			
			FileOutputStream fos = new FileOutputStream(f);
			fos.write("{\n\n}".getBytes());
			fos.flush();
			fos.close();
			return;
		}

		StringBuilder convertedJson = new StringBuilder();
		BufferedReader br = new BufferedReader(new FileReader(f));
		String str = null;
		while ((str = br.readLine()) != null) {
			convertedJson.append(str + "\n");
		}
		br.close();

		JSONObject obj = new JSONObject(convertedJson.toString());
		ArrayList<String> keys = new ArrayList<String>(obj.keySet());

		for (String k : keys) {
			LCCertificate cer = new LCCertificate();
			JSONObject o = obj.getJSONObject(k);
			ArrayList<String> keys2 = new ArrayList<String>(o.keySet());
			cer.email = k;
			cer.identifier = k.split("@")[0];
			for (String k2 : keys2) {
				if (k2.equalsIgnoreCase("publickey")) {
					cer.base64publicKey = o.getString(k2);
				} else if (k2.equalsIgnoreCase("privatekey")) {
					cer.base64privateKey = o.getString(k2);
				} else if (k2.equalsIgnoreCase("password")) {
					cer.hashedPassword = o.getString(k2);
				}
			}
			loadedCerts.add(cer);
			System.out.println("Cert loaded for: " + cer.email);
		}
	}

	private void saveCerts() throws IOException {
		StringBuilder jsonFile = new StringBuilder();

		jsonFile.append("{");

		for (int i = 0;i<loadedCerts.size();i++) {
			LCCertificate cer = loadedCerts.get(i);
			jsonFile.append("\"" + cer.email + "\": {");

			if (cer.base64publicKey != null && cer.base64privateKey == null) {
				jsonFile.append("\"publickey\": " + "\"" + cer.base64publicKey + "\"");
			} else {
				jsonFile.append("\"publickey\": " + "\"" + cer.base64publicKey + "\",");
				jsonFile.append("\"privatekey\": " + "\"" + cer.base64privateKey + "\",");
				jsonFile.append("\"password\": " + "\"" + cer.hashedPassword + "\"");
			}

			if (i == loadedCerts.size() - 1) {
				jsonFile.append("}");
			} else {
				jsonFile.append("},");
			}
		}

		jsonFile.append("}");

		String certStore = LiteCryptor.certStorePath();
		File f = new File(certStore + "\\certificates.json");
		if (f.exists()) {
			f.delete();
			f.createNewFile();
		}
		BufferedWriter bw = new BufferedWriter(new FileWriter(f));
		bw.write(jsonFile.toString());
		bw.flush();
		bw.close();
	}
	
	public boolean hasPrivateKey(String email) {
		for (LCCertificate cert : loadedCerts) {
			if (cert.email.equalsIgnoreCase(email)) {
				if (cert.base64privateKey != null) {
					return true;
				}
			}
		}
		return false;
	}

	public String parseLCKeyEmail(String key) {
		String tmp = key.replace("---------- LiteCrypto Public ----------", "");
		tmp = tmp.replaceAll("\n", "");
		tmp = tmp.trim();
		return new String(Base64.getDecoder().decode(tmp.split("#")[0].getBytes()));
	}

	public String parseLCKeyEncodedPublicKey(String key) {
		String tmp = key.replace("---------- LiteCrypto Public ----------", "");
		tmp = tmp.replaceAll("\n", "");
		tmp = tmp.trim();
		return tmp.split("#")[1];
	}

	public ArrayList<LCCertificate> getLoadedCertificates() {
		return loadedCerts;
	}

	public void removeCertificateByIdentifer(String identifer) {
		int index = 0;

		for (int i = 0;i<loadedCerts.size();i++) {
			LCCertificate cert = loadedCerts.get(i);
			if (cert.identifier.equalsIgnoreCase(identifer)) {
				index = i;
				break;
			}
		}

		loadedCerts.remove(index);

		try {
			saveCerts();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void removeCertificateByEmail(String email) {
		int index = 0;

		for (int i = 0;i<loadedCerts.size();i++) {
			LCCertificate cert = loadedCerts.get(i);
			if (cert.email.equalsIgnoreCase(email)) {
				index = i;
				break;
			}
		}

		loadedCerts.remove(index);

		try {
			saveCerts();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public LCCertificate getCertificateByIdentifier(String identifer) {
		for (LCCertificate c : loadedCerts) {
			if (c.identifier.equalsIgnoreCase(identifer)) {
				return c;
			}
		}
		return null;
	}

	public LCCertificate getCertificateByEmail(String email) {
		for (LCCertificate c : loadedCerts) {
			if (c.email.equalsIgnoreCase(email)) {
				return c;
			}
		}
		return null;
	}

	public void createCertificateStorage(String identifier, String email, String hashedPassword, PublicKey pk, PrivateKey privk) {
		MessageDigest digest = null;
		try {
			digest = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		byte[] hashedP = digest.digest(hashedPassword.getBytes(StandardCharsets.UTF_8));
		
		String convertedHashedPassword = Base64.getEncoder().encodeToString(hashedP);
		
		LCCertificate cert = new LCCertificate();
		cert.identifier = identifier;
		cert.email = email;
		cert.hashedPassword = convertedHashedPassword;
		cert.base64publicKey = Base64.getEncoder().encodeToString(pk.getEncoded());
		cert.base64privateKey = Base64.getEncoder().encodeToString(privk.getEncoded());
		loadedCerts.add(cert);

		try {
			saveCerts();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void createCertificateStorage(String identifier, String email, PublicKey pk) {
		LCCertificate cert = new LCCertificate();
		cert.identifier = identifier;
		cert.email = email;
		cert.base64publicKey = Base64.getEncoder().encodeToString(pk.getEncoded());
		loadedCerts.add(cert);

		try {
			saveCerts();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
