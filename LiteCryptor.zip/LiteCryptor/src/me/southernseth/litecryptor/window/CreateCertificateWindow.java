package me.southernseth.litecryptor.window;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import me.southernseth.litecryptor.LiteCryptor;
import me.southernseth.litecryptor.util.RSAUtil;

public class CreateCertificateWindow extends JDialog {

	private static final long serialVersionUID = 2604671664706543388L;
	
	private ArrayList<Integer> clicks = new ArrayList<Integer>();
	
	private JDialog instance;

	public CreateCertificateWindow(LiteCryptor window) {
		instance = this;
		
		window.getWindow().setEnabled(false);

		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.setPreferredSize(new Dimension(600, 400));
		
		JLabel emailLabel = new JLabel("Email");
		JTextField emailField = new JTextField();
		
		JLabel passwordLabel = new JLabel("Password");
		JPasswordField password1 = new JPasswordField();
		
		JLabel password2Label = new JLabel("Password Confirmation");
		JPasswordField password2 = new JPasswordField();
		
		JLabel seedLabel = new JLabel("Seed");
		JPanel seedPanel = new JPanel();
		seedPanel.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				int value = e.getX() + e.getY();
				clicks.add(value);
				
				Graphics2D g2 = (Graphics2D) seedPanel.getGraphics();
				g2.setColor(Color.RED);
				g2.fillOval(e.getX(), e.getY(), 5, 5);
				g2.dispose();
			}

			@Override
			public void mouseReleased(MouseEvent e) {
			}
		});
		seedPanel.setBackground(Color.GRAY);
		
		JButton create = new JButton("Generate Key Pair");
		create.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (password1.getPassword().length == 0 || password2.getPassword().length == 0) {
					JOptionPane.showMessageDialog(instance, "You cannot leave any of the password fields blank!", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if (!doPasswordsMatch(password1.getPassword(), password2.getPassword())) {
					JOptionPane.showMessageDialog(instance, "The passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if (emailField.getText().isEmpty() || emailField.getText() == null) {
					JOptionPane.showMessageDialog(instance, "You must enter an email address!", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				long value = 0;
				byte[] s = null;
				
				if (clicks.size() != 0) {
					Random rr = new Random();
					
					while (value == 0 || value < 999999999999L) {
						for (int i : clicks) {
							int r = rr.nextInt(10);
							if (r < 3) {
								value *= i;
							} else if (r > 3 && r < 7) {
								value += i % 2;
							} else if (r > 7) {
								value /= i;
							}
						}
					}
					
					String seed = String.valueOf(value);
					s = seed.getBytes();
				} else {
					try {
						SecureRandom r = SecureRandom.getInstanceStrong();
						s = r.generateSeed(32);
					} catch (NoSuchAlgorithmException e1) {
						e1.printStackTrace();
					}
				}
				
				KeyPair kP = RSAUtil.generateKeys(emailField.getText(), new String(password1.getPassword()), s, System.getProperty("user.home") + "\\.LiteCrypto");
				window.getCertManager().createCertificateStorage(emailField.getText().split("@")[0], emailField.getText(), new String(password1.getPassword()), kP.getPublic(), kP.getPrivate());
				
				window.getWindow().setEnabled(true);
				dispose();
				
				JOptionPane.showMessageDialog(instance, "Certificates for \"" + emailField.getText() + "\" were created successfully!");
			}
		});
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.insets = new Insets(0,5,0,5);
		panel.add(emailLabel, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.insets = new Insets(0,5,15,5);
		panel.add(emailField, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 1;
		gbc.insets = new Insets(0,5,0,5);
		panel.add(passwordLabel, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.weightx = 1;
		gbc.insets = new Insets(0,5,5,5);
		panel.add(password1, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.weightx = 1;
		gbc.insets = new Insets(0,5,0,5);
		panel.add(password2Label, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.weightx = 1;
		gbc.anchor = GridBagConstraints.NORTH;
		gbc.insets = new Insets(0,5,15,5);
		panel.add(password2, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.insets = new Insets(0,5,0,5);
		panel.add(seedLabel, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.gridheight = 5;
		gbc.ipady = 300;
		gbc.insets = new Insets(0,5,15,5);
		panel.add(seedPanel, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 6;
		gbc.weightx = 1;
		gbc.gridwidth = 2;
		panel.add(create, gbc);

		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		setTitle("Generate Key Pair");
		setContentPane(panel);
		pack();
		setLocationRelativeTo(window.getWindow());
		setMinimumSize(getSize());
		setResizable(false);
		setVisible(true);

		addWindowListener(new WindowListener() {
			@Override
			public void windowOpened(WindowEvent arg0) {
			}

			@Override
			public void windowIconified(WindowEvent arg0) {
			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
			}

			@Override
			public void windowClosing(WindowEvent arg0) {
				window.getWindow().setEnabled(true);
				dispose();
			}

			@Override
			public void windowClosed(WindowEvent arg0) {
			}

			@Override
			public void windowActivated(WindowEvent arg0) {
			}
		});
	}
	
	private boolean doPasswordsMatch(char[] pass, char[] compPass) {
		if (pass.length != compPass.length) {
			return false;
		}
		
		for (int i = 0;i<pass.length;i++) {
			char c = pass[i];
			char c2 = compPass[i];
			
			if (c != c2) {
				return false;
			}
		}
		return true;
	}

}
