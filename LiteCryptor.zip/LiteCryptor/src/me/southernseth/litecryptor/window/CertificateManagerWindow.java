package me.southernseth.litecryptor.window;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import me.southernseth.litecryptor.LiteCryptor;

public class CertificateManagerWindow extends JDialog {

	private static final long serialVersionUID = 6792531005072255363L;

	private JDialog w;
	private LiteCryptor liteCryptor;

	public CertificateManagerWindow(LiteCryptor window) {
		w = this;
		liteCryptor = window;

		window.getWindow().setEnabled(false);

		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		setTitle("Certificate Manager");
		setContentPane(mainPanel());
		pack();
		setLocationRelativeTo(window.getWindow());
		setMinimumSize(getSize());
		setAlwaysOnTop(true);
		setResizable(false);
		setVisible(true);

		addWindowListener(new WindowListener() {
			@Override
			public void windowOpened(WindowEvent arg0) {
			}

			@Override
			public void windowIconified(WindowEvent arg0) {
			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
			}

			@Override
			public void windowClosing(WindowEvent arg0) {
				window.getWindow().setEnabled(true);
				dispose();
			}

			@Override
			public void windowClosed(WindowEvent arg0) {
			}

			@Override
			public void windowActivated(WindowEvent arg0) {
			}
		});
	}

	public JPanel addCertPanel() {
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.setPreferredSize(new Dimension(500, 200));

		JTextArea publicKeyInput = new JTextArea();
		JScrollPane publicKeyPane = new JScrollPane(publicKeyInput);

		JButton add = new JButton("Add Certificate");

		add.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (publicKeyInput.getText().startsWith("---------- LiteCrypto Public ----------") && publicKeyInput.getText().endsWith("---------- LiteCrypto Public ----------")) {
					String email = liteCryptor.getCertManager().parseLCKeyEmail(publicKeyInput.getText());
					String pk = liteCryptor.getCertManager().parseLCKeyEncodedPublicKey(publicKeyInput.getText());
					
					if (email == null || pk == null) {
						JOptionPane.showMessageDialog(w, "Unable to read the provided LiteCrypto key", "Error Adding Certificate", JOptionPane.ERROR_MESSAGE);
						setTitle("Certificate Manager");
						setContentPane(mainPanel());
						repaint();
						revalidate();
						return;
					}

					byte[] publicKey = Base64.getDecoder().decode(pk);
					PublicKey pki = null;
					KeyFactory kf = null;
					try {
						kf = KeyFactory.getInstance("RSA");
						pki = kf.generatePublic(new X509EncodedKeySpec(publicKey));
					} catch (InvalidKeySpecException | NoSuchAlgorithmException e1) {
						e1.printStackTrace();
					}

					liteCryptor.getCertManager().createCertificateStorage(email.split("@")[0], email, pki);
					
					JOptionPane.showMessageDialog(w, "Successfully added public key for \"" + email + "\"", "Certificate Added", JOptionPane.INFORMATION_MESSAGE);
					
					setTitle("Certificate Manager");
					setContentPane(mainPanel());
					repaint();
					revalidate();
					return;
				} else {
					JOptionPane.showMessageDialog(w, "Unable to read the provided LiteCrypto key", "Error Adding Certificate", JOptionPane.ERROR_MESSAGE);
					setTitle("Certificate Manager");
					setContentPane(mainPanel());
					repaint();
					revalidate();
					return;
				}
			}
		});

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 0.9;
		gbc.insets = new Insets(5,5,5,5);
		panel.add(publicKeyPane, gbc);

		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.weighty = 0.1;
		gbc.insets = new Insets(0,5,0,5);
		panel.add(add, gbc);

		return panel;
	}

	public JPanel mainPanel() {
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.setPreferredSize(new Dimension(500, 200));

		String[] data = null;
		if (liteCryptor.getCertManager().getLoadedCertificates().size() < 1) {
			data = new String[] { "No Certificates Loaded" };
		} else {
			data = new String[liteCryptor.getCertManager().getLoadedCertificates().size()];
			for (int i = 0;i<liteCryptor.getCertManager().getLoadedCertificates().size();i++) {
				
				data[i] = liteCryptor.getCertManager().getLoadedCertificates().get(i).email;
			}
		}

		JList<String> certificates = new JList<String>(data);
		JScrollPane certScrollPane = new JScrollPane(certificates);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 0.9;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(5,5,5,5);
		panel.add(certScrollPane, gbc);

		JButton addCert = new JButton("Add");
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.weighty = 0.1;
		gbc.insets = new Insets(0,5,0,5);
		panel.add(addCert, gbc);

		JButton removeCert = new JButton("Remove");
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.weighty = 0.1;
		gbc.insets = new Insets(0,5,0,5);
		panel.add(removeCert, gbc);

		removeCert.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (certificates.isSelectionEmpty()) {
					JOptionPane.showMessageDialog(w, "There is not certificate selected to remove", "Error Removing Certificate", JOptionPane.ERROR_MESSAGE);
					return;
				} else if (certificates.getSelectedValue().equalsIgnoreCase("No Certificates Loaded")) {
					JOptionPane.showMessageDialog(w, "There is not certificate selected to remove", "Error Removing Certificate", JOptionPane.ERROR_MESSAGE);
					return;
				} else {
					liteCryptor.getCertManager().removeCertificateByEmail(certificates.getSelectedValue());
					certificates.remove(certificates.getSelectedIndex());
					JOptionPane.showMessageDialog(w, "Certificate \"" + certificates.getSelectedValue() + "\" was removed successfully", "Certificate Removed", JOptionPane.INFORMATION_MESSAGE);
					dispose();
					new CertificateManagerWindow(liteCryptor);
					return;
				}
			}
		});

		addCert.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setTitle("Certificate Manager - Add");
				setContentPane(addCertPanel());
				repaint();
				revalidate();
			}
		});

		return panel;
	}

}
