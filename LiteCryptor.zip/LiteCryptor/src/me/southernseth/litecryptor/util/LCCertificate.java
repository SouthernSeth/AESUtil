package me.southernseth.litecryptor.util;

public class LCCertificate {
	
	public String identifier;
	public String email;
	public String hashedPassword;
	public String base64publicKey;
	public String base64privateKey;

}
