package com.jordan.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL30;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector3;
import com.jordan.game.LibgdxGame;
import com.jordan.game.entities.Player;
import com.jordan.game.entities.TileType;
import com.jordan.game.util.AssetLoader;

public class GameScreen implements Screen {

	private LibgdxGame game;

	private float gameState = 0;

	private OrthographicCamera camera;
	private SpriteBatch batch;
	private ShapeRenderer shapeR;
	private AssetLoader assetLoader;

	private Player plr;

	public GameScreen(LibgdxGame game, AssetLoader assetLoader) {
		this.game = game;
		this.camera = game.getCamera();
		this.batch = game.getBatch();
		this.assetLoader = assetLoader;
	}

	@Override
	public void dispose() {
		batch.dispose();
	}

	@Override
	public void hide() {

	}

	@Override
	public void pause() {

	}

	@Override
	public void render(float delta) {
		if (Gdx.input.isKeyPressed(Keys.ESCAPE)) {
			Gdx.app.exit();
		}
		
		gameState += Gdx.graphics.getDeltaTime();

		Gdx.gl.glClearColor( 0.6f, 1f, 0.6f, 1f );
		Gdx.gl.glClear( GL30.GL_COLOR_BUFFER_BIT | GL30.GL_DEPTH_BUFFER_BIT );

		TextureRegion grass = assetLoader.getTile(TileType.GRASS);

		camera.position.set(plr.getOriginX(), plr.getOriginY(), 0);
		camera.update();

		batch.setProjectionMatrix(camera.combined);
		batch.begin();

		for (int y = 0;y<25;y++) {
			for (int x = 0;x<25;x++) {
				batch.draw(grass, x * grass.getRegionWidth(), y * grass.getRegionHeight());
			}
		}
		
		plr.render(delta, gameState);

		batch.end();
		
		Vector3 mouse = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
		mouse = camera.unproject(mouse);
		
		shapeR.setColor(Color.RED);
		shapeR.setProjectionMatrix(camera.combined);
		shapeR.begin(ShapeType.Filled);
		shapeR.circle(mouse.x, mouse.y, 10);
		shapeR.end();
	}

	@Override
	public void resize(int w, int h) {

	}

	@Override
	public void resume() {
	}

	@Override
	public void show() {
		Gdx.input.setCursorCatched(true);
		
		camera.zoom = 2f;
		camera.update();
		
		plr = new Player(assetLoader, camera, batch, 500, 500);
		shapeR = new ShapeRenderer();
	}

}
