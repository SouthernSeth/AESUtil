package com.jordan.game.screens;

import java.text.DecimalFormat;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL30;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.jordan.game.LibgdxGame;
import com.jordan.game.util.AssetLoader;

public class StartScreen implements Screen {
	
	private LibgdxGame game;
	
	private OrthographicCamera camera;
	private SpriteBatch batch;
	private AssetLoader assetLoader;
	
	private BitmapFont font;
	
	public StartScreen(LibgdxGame game) {
		this.game = game;
		this.camera = game.getCamera();
		this.batch = game.getBatch();
		
		assetLoader = new AssetLoader();
	}

	@Override
	public void dispose() {
	}

	@Override
	public void hide() {
	}

	@Override
	public void pause() {
	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor( 0f, 0f, 0f, 1f );
		Gdx.gl.glClear( GL30.GL_COLOR_BUFFER_BIT | GL30.GL_DEPTH_BUFFER_BIT );
		
		if (assetLoader.getAssetLoader().update()) {
			assetLoader.load(game);
		} else {
			double percentage = assetLoader.getAssetLoader().getProgress() * 100;
			DecimalFormat format = new DecimalFormat("##");
			
			String value = "Loading Assets: " + format.format(percentage) + "%";
			String value2 = "Assets Currently Loaded: " + assetLoader.getAssetLoader().getLoadedAssets();
			
			batch.setProjectionMatrix(camera.combined);
			batch.begin();
			font.draw(batch, value, 0 - (font.getSpaceWidth() * value.length()) - value.length(), 0);
			font.draw(batch, value2, 0 - (font.getSpaceWidth() * value2.length()) - value2.length(), -16);
			batch.end();
		}
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void resume() {
	}

	@Override
	public void show() {
		font = new BitmapFont();
	}

}
