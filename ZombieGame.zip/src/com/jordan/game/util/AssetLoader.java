package com.jordan.game.util;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.jordan.game.LibgdxGame;
import com.jordan.game.entities.TileType;
import com.jordan.game.screens.GameScreen;

public class AssetLoader {

	private AssetManager assetManager;

	private Animation<TextureRegion> feet_idle;
	private Animation<TextureRegion> feet_run;
	private Animation<TextureRegion> feet_strafe_left;
	private Animation<TextureRegion> feet_strafe_right;
	private Animation<TextureRegion> feet_walk;

	private Animation<TextureRegion> flashlight_idle;
	private Animation<TextureRegion> flashlight_melee;
	private Animation<TextureRegion> flashlight_move;

	private Animation<TextureRegion> knife_idle;
	private Animation<TextureRegion> knife_melee;
	private Animation<TextureRegion> knife_move;

	private Animation<TextureRegion> handgun_idle;
	private Animation<TextureRegion> handgun_melee;
	private Animation<TextureRegion> handgun_move;
	private Animation<TextureRegion> handgun_reload;
	private Animation<TextureRegion> handgun_shoot;

	private Animation<TextureRegion> rifle_idle;
	private Animation<TextureRegion> rifle_melee;
	private Animation<TextureRegion> rifle_move;
	private Animation<TextureRegion> rifle_reload;
	private Animation<TextureRegion> rifle_shoot;

	private Animation<TextureRegion> shotgun_idle;
	private Animation<TextureRegion> shotgun_melee;
	private Animation<TextureRegion> shotgun_move;
	private Animation<TextureRegion> shotgun_reload;
	private Animation<TextureRegion> shotgun_shoot;

	private Animation<TextureRegion> zombie_idle;
	private Animation<TextureRegion> zombie_move;
	private Animation<TextureRegion> zombie_attack;

	private TextureRegion grass_tile;

	public AssetLoader() {
		assetManager = new AssetManager();

		assetManager.load("survivor/feet/idle/survivor-idle_0.png", Texture.class);

		assetManager.load("survivor/feet/run/survivor-run_0.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_1.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_2.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_3.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_4.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_5.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_6.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_7.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_8.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_9.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_10.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_11.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_12.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_13.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_14.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_15.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_16.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_17.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_18.png", Texture.class);
		assetManager.load("survivor/feet/run/survivor-run_19.png", Texture.class);

		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_0.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_1.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_2.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_3.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_4.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_5.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_6.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_7.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_8.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_9.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_10.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_11.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_12.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_13.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_14.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_15.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_16.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_17.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_18.png", Texture.class);
		assetManager.load("survivor/feet/strafe_left/survivor-strafe_left_19.png", Texture.class);

		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_0.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_1.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_2.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_3.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_4.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_5.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_6.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_7.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_8.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_9.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_10.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_11.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_12.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_13.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_14.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_15.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_16.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_17.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_18.png", Texture.class);
		assetManager.load("survivor/feet/strafe_right/survivor-strafe_right_19.png", Texture.class);

		assetManager.load("survivor/feet/walk/survivor-walk_0.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_1.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_2.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_3.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_4.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_5.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_6.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_7.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_8.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_9.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_10.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_11.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_12.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_13.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_14.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_15.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_16.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_17.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_18.png", Texture.class);
		assetManager.load("survivor/feet/walk/survivor-walk_19.png", Texture.class);

		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_0.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_1.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_2.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_3.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_4.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_5.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_6.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_7.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_8.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_9.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_10.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_11.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_12.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_13.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_14.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_15.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_16.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_17.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_18.png", Texture.class);
		assetManager.load("survivor/flashlight/idle/survivor-idle_flashlight_19.png", Texture.class);

		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_0.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_1.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_2.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_3.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_4.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_5.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_6.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_7.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_8.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_9.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_10.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_11.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_12.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_13.png", Texture.class);
		assetManager.load("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_14.png", Texture.class);

		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_0.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_1.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_2.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_3.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_4.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_5.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_6.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_7.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_8.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_9.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_10.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_11.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_12.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_13.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_14.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_15.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_16.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_17.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_18.png", Texture.class);
		assetManager.load("survivor/flashlight/move/survivor-move_flashlight_19.png", Texture.class);

		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_0.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_1.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_2.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_3.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_4.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_5.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_6.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_7.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_8.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_9.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_10.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_11.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_12.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_13.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_14.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_15.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_16.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_17.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_18.png", Texture.class);
		assetManager.load("survivor/handgun/idle/survivor-idle_handgun_19.png", Texture.class);

		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_0.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_1.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_2.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_3.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_4.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_5.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_6.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_7.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_8.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_9.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_10.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_11.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_12.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_13.png", Texture.class);
		assetManager.load("survivor/handgun/meleeattack/survivor-meleeattack_handgun_14.png", Texture.class);

		assetManager.load("survivor/handgun/move/survivor-move_handgun_0.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_1.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_2.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_3.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_4.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_5.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_6.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_7.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_8.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_9.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_10.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_11.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_12.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_13.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_14.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_15.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_16.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_17.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_18.png", Texture.class);
		assetManager.load("survivor/handgun/move/survivor-move_handgun_19.png", Texture.class);

		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_0.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_1.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_2.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_3.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_4.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_5.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_6.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_7.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_8.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_9.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_10.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_11.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_12.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_13.png", Texture.class);
		assetManager.load("survivor/handgun/reload/survivor-reload_handgun_14.png", Texture.class);

		assetManager.load("survivor/handgun/shoot/survivor-shoot_handgun_0.png", Texture.class);
		assetManager.load("survivor/handgun/shoot/survivor-shoot_handgun_1.png", Texture.class);
		assetManager.load("survivor/handgun/shoot/survivor-shoot_handgun_2.png", Texture.class);

		assetManager.load("survivor/knife/idle/survivor-idle_knife_0.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_1.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_2.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_3.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_4.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_5.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_6.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_7.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_8.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_9.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_10.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_11.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_12.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_13.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_14.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_15.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_16.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_17.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_18.png", Texture.class);
		assetManager.load("survivor/knife/idle/survivor-idle_knife_19.png", Texture.class);

		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_0.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_1.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_2.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_3.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_4.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_5.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_6.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_7.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_8.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_9.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_10.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_11.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_12.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_13.png", Texture.class);
		assetManager.load("survivor/knife/meleeattack/survivor-meleeattack_knife_14.png", Texture.class);

		assetManager.load("survivor/knife/move/survivor-move_knife_0.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_1.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_2.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_3.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_4.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_5.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_6.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_7.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_8.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_9.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_10.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_11.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_12.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_13.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_14.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_15.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_16.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_17.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_18.png", Texture.class);
		assetManager.load("survivor/knife/move/survivor-move_knife_19.png", Texture.class);

		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_0.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_1.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_2.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_3.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_4.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_5.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_6.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_7.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_8.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_9.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_10.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_11.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_12.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_13.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_14.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_15.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_16.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_17.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_18.png", Texture.class);
		assetManager.load("survivor/rifle/idle/survivor-idle_rifle_19.png", Texture.class);

		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_0.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_1.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_2.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_3.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_4.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_5.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_6.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_7.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_8.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_9.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_10.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_11.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_12.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_13.png", Texture.class);
		assetManager.load("survivor/rifle/meleeattack/survivor-meleeattack_rifle_14.png", Texture.class);

		assetManager.load("survivor/rifle/move/survivor-move_rifle_0.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_1.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_2.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_3.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_4.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_5.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_6.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_7.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_8.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_9.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_10.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_11.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_12.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_13.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_14.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_15.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_16.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_17.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_18.png", Texture.class);
		assetManager.load("survivor/rifle/move/survivor-move_rifle_19.png", Texture.class);

		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_0.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_1.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_2.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_3.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_4.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_5.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_6.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_7.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_8.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_9.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_10.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_11.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_12.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_13.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_14.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_15.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_16.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_17.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_18.png", Texture.class);
		assetManager.load("survivor/rifle/reload/survivor-reload_rifle_19.png", Texture.class);

		assetManager.load("survivor/rifle/shoot/survivor-shoot_rifle_0.png", Texture.class);
		assetManager.load("survivor/rifle/shoot/survivor-shoot_rifle_1.png", Texture.class);
		assetManager.load("survivor/rifle/shoot/survivor-shoot_rifle_2.png", Texture.class);

		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_0.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_1.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_2.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_3.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_4.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_5.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_6.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_7.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_8.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_9.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_10.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_11.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_12.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_13.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_14.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_15.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_16.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_17.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_18.png", Texture.class);
		assetManager.load("survivor/shotgun/idle/survivor-idle_shotgun_19.png", Texture.class);

		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_0.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_1.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_2.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_3.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_4.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_5.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_6.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_7.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_8.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_9.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_10.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_11.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_12.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_13.png", Texture.class);
		assetManager.load("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_14.png", Texture.class);

		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_0.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_1.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_2.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_3.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_4.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_5.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_6.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_7.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_8.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_9.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_10.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_11.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_12.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_13.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_14.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_15.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_16.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_17.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_18.png", Texture.class);
		assetManager.load("survivor/shotgun/move/survivor-move_shotgun_19.png", Texture.class);

		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_0.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_1.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_2.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_3.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_4.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_5.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_6.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_7.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_8.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_9.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_10.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_11.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_12.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_13.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_14.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_15.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_16.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_17.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_18.png", Texture.class);
		assetManager.load("survivor/shotgun/reload/survivor-reload_shotgun_19.png", Texture.class);

		assetManager.load("survivor/shotgun/shoot/survivor-shoot_shotgun_0.png", Texture.class);
		assetManager.load("survivor/shotgun/shoot/survivor-shoot_shotgun_1.png", Texture.class);
		assetManager.load("survivor/shotgun/shoot/survivor-shoot_shotgun_2.png", Texture.class);

		assetManager.load("zombie/attack/skeleton-attack_0.png", Texture.class);
		assetManager.load("zombie/attack/skeleton-attack_1.png", Texture.class);
		assetManager.load("zombie/attack/skeleton-attack_2.png", Texture.class);
		assetManager.load("zombie/attack/skeleton-attack_3.png", Texture.class);
		assetManager.load("zombie/attack/skeleton-attack_4.png", Texture.class);
		assetManager.load("zombie/attack/skeleton-attack_5.png", Texture.class);
		assetManager.load("zombie/attack/skeleton-attack_6.png", Texture.class);
		assetManager.load("zombie/attack/skeleton-attack_7.png", Texture.class);
		assetManager.load("zombie/attack/skeleton-attack_8.png", Texture.class);

		assetManager.load("zombie/idle/skeleton-idle_0.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_1.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_2.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_3.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_4.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_5.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_6.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_7.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_8.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_9.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_10.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_11.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_12.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_13.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_14.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_15.png", Texture.class);
		assetManager.load("zombie/idle/skeleton-idle_16.png", Texture.class);

		assetManager.load("zombie/move/skeleton-move_0.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_1.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_2.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_3.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_4.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_5.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_6.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_7.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_8.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_9.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_10.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_11.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_12.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_13.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_14.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_15.png", Texture.class);
		assetManager.load("zombie/move/skeleton-move_16.png", Texture.class);

		assetManager.load("tiles/grass.png", Texture.class);
	}

	public void load(LibgdxGame game) {
		TextureRegion[] tr = new TextureRegion[1];
		for (int i = 0;i<1;i++) {
			Texture texture = assetManager.get("survivor/feet/idle/survivor-idle_0.png");
			tr[i] = new TextureRegion(texture);
		}
		feet_idle = new Animation<TextureRegion>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/feet/run/survivor-run_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		feet_run = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/feet/strafe_left/survivor-strafe_left_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		feet_strafe_left = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/feet/strafe_right/survivor-strafe_right_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		feet_strafe_right = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/feet/walk/survivor-walk_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		feet_walk = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/feet/walk/survivor-walk_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		feet_walk = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/feet/walk/survivor-walk_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		feet_walk = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/flashlight/idle/survivor-idle_flashlight_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		flashlight_idle = new Animation<>(0.025f, tr);

		tr = new TextureRegion[15];
		for (int i = 0;i<15;i++) {
			Texture texture = assetManager.get("survivor/flashlight/meleeattack/survivor-meleeattack_flashlight_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		flashlight_melee = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/flashlight/move/survivor-move_flashlight_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		flashlight_move = new Animation<>(0.025f, tr);
		
		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/knife/idle/survivor-idle_knife_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		knife_idle = new Animation<>(0.025f, tr);

		tr = new TextureRegion[15];
		for (int i = 0;i<15;i++) {
			Texture texture = assetManager.get("survivor/knife/meleeattack/survivor-meleeattack_knife_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		knife_melee = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/knife/move/survivor-move_knife_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		knife_move = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/handgun/idle/survivor-idle_handgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		handgun_idle = new Animation<>(0.025f, tr);

		tr = new TextureRegion[15];
		for (int i = 0;i<15;i++) {
			Texture texture = assetManager.get("survivor/handgun/meleeattack/survivor-meleeattack_handgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		handgun_melee = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/handgun/move/survivor-move_handgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		handgun_move = new Animation<>(0.025f, tr);

		tr = new TextureRegion[15];
		for (int i = 0;i<15;i++) {
			Texture texture = assetManager.get("survivor/handgun/reload/survivor-reload_handgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		handgun_reload = new Animation<>(0.025f, tr);

		tr = new TextureRegion[3];
		for (int i = 0;i<3;i++) {
			Texture texture = assetManager.get("survivor/handgun/shoot/survivor-shoot_handgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		handgun_shoot = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/rifle/idle/survivor-idle_rifle_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		rifle_idle = new Animation<>(0.025f, tr);

		tr = new TextureRegion[15];
		for (int i = 0;i<15;i++) {
			Texture texture = assetManager.get("survivor/rifle/meleeattack/survivor-meleeattack_rifle_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		rifle_melee = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/rifle/move/survivor-move_rifle_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		rifle_move = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/rifle/reload/survivor-reload_rifle_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		rifle_reload = new Animation<>(0.025f, tr);

		tr = new TextureRegion[3];
		for (int i = 0;i<3;i++) {
			Texture texture = assetManager.get("survivor/rifle/shoot/survivor-shoot_rifle_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		rifle_shoot = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/shotgun/idle/survivor-idle_shotgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		shotgun_idle = new Animation<>(0.025f, tr);

		tr = new TextureRegion[15];
		for (int i = 0;i<15;i++) {
			Texture texture = assetManager.get("survivor/shotgun/meleeattack/survivor-meleeattack_shotgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		shotgun_melee = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/shotgun/move/survivor-move_shotgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		shotgun_move = new Animation<>(0.025f, tr);

		tr = new TextureRegion[20];
		for (int i = 0;i<20;i++) {
			Texture texture = assetManager.get("survivor/shotgun/reload/survivor-reload_shotgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		shotgun_reload = new Animation<>(0.025f, tr);

		tr = new TextureRegion[3];
		for (int i = 0;i<3;i++) {
			Texture texture = assetManager.get("survivor/shotgun/shoot/survivor-shoot_shotgun_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		shotgun_shoot = new Animation<>(0.025f, tr);

		tr = new TextureRegion[17];
		for (int i = 0;i<17;i++) {
			Texture texture = assetManager.get("zombie/idle/skeleton-idle_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		zombie_idle = new Animation<>(0.025f, tr);

		tr = new TextureRegion[17];
		for (int i = 0;i<17;i++) {
			Texture texture = assetManager.get("zombie/move/skeleton-move_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		zombie_move = new Animation<>(0.025f, tr);

		tr = new TextureRegion[9];
		for (int i = 0;i<9;i++) {
			Texture texture = assetManager.get("zombie/attack/skeleton-attack_" + i + ".png");
			tr[i] = new TextureRegion(texture);
		}
		zombie_attack = new Animation<>(0.025f, tr);

		Texture texture = assetManager.get("tiles/grass.png");
		grass_tile = new TextureRegion(texture);

		game.setScreen(new GameScreen(game, this));
	}

	public TextureRegion getTile(TileType tile) {
		switch (tile) {
		case GRASS:
			return grass_tile;
		default:
			return grass_tile;
		}
	}

	public Animation<TextureRegion> getFeetIdle() {
		return feet_idle;
	}

	public Animation<TextureRegion> getFeetWalk() {
		return feet_walk;
	}

	public Animation<TextureRegion> getFeetRun() {
		return feet_run;
	}

	public Animation<TextureRegion> getFeetStrafeLeft() {
		return feet_strafe_left;
	}

	public Animation<TextureRegion> getFeetStrafeRight() {
		return feet_strafe_right;
	}

	public Animation<TextureRegion> getFlashlightIdle() {
		return flashlight_idle;
	}

	public Animation<TextureRegion> getFlashlightMelee() {
		return flashlight_melee;
	}

	public Animation<TextureRegion> getFlashlightMove() {
		return flashlight_move;
	}

	public Animation<TextureRegion> getKnifeIdle() {
		return knife_idle;
	}

	public Animation<TextureRegion> getKnifeMelee() {
		return knife_melee;
	}

	public Animation<TextureRegion> getKnifeMove() {
		return knife_move;
	}

	public Animation<TextureRegion> getHandgunIdle() {
		return handgun_idle;
	}

	public Animation<TextureRegion> getHandgunMelee() {
		return handgun_melee;
	}

	public Animation<TextureRegion> getHandgunMove() {
		return handgun_move;
	}

	public Animation<TextureRegion> getHandgunReload() {
		return handgun_reload;
	}

	public Animation<TextureRegion> getHandgunShoot() {
		return handgun_shoot;
	}

	public Animation<TextureRegion> getRifleIdle() {
		return rifle_idle;
	}

	public Animation<TextureRegion> getRifleMelee() {
		return rifle_melee;
	}

	public Animation<TextureRegion> getRifleMove() {
		return rifle_move;
	}

	public Animation<TextureRegion> getRifleReload() {
		return rifle_reload;
	}

	public Animation<TextureRegion> getRifleShoot() {
		return rifle_shoot;
	}

	public Animation<TextureRegion> getShotgunIdle() {
		return shotgun_idle;
	}

	public Animation<TextureRegion> getShotgunMelee() {
		return shotgun_melee;
	}

	public Animation<TextureRegion> getShotgunMove() {
		return shotgun_move;
	}

	public Animation<TextureRegion> getShotgunReload() {
		return shotgun_reload;
	}

	public Animation<TextureRegion> getShotgunShoot() {
		return shotgun_shoot;
	}

	public Animation<TextureRegion> getZombieIdle() {
		return zombie_idle;
	}

	public Animation<TextureRegion> getZombieMove() {
		return zombie_move;
	}

	public Animation<TextureRegion> getZombieAttack() {
		return zombie_attack;
	}

	public AssetManager getAssetLoader() {
		return assetManager;
	}

}
