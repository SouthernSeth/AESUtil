package com.jordan.game;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;

public class Start {
	
	public static void main(String[] args) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.vSyncEnabled = false;
		config.resizable = false;
		config.width = 1280;
		config.height = 720;
		new LwjglApplication(new LibgdxGame(), config);
	}

}
