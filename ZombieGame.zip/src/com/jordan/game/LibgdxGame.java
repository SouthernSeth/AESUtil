package com.jordan.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.jordan.game.screens.StartScreen;

public class LibgdxGame extends Game {
	
	private OrthographicCamera camera;
	private SpriteBatch batch;

	@Override
	public void create() {
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 1280, 720);
		camera.position.set(0, 0, 0);
		camera.update();

		batch = new SpriteBatch();
		
		setScreen(new StartScreen(this));
	}
	
	public OrthographicCamera getCamera() {
		return camera;
	}
	
	public SpriteBatch getBatch() {
		return batch;
	}

}
