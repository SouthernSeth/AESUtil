package com.jordan.game.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Animation.PlayMode;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.jordan.game.util.AssetLoader;

public class Player {

	private Vector2 position;
	private float degrees;
	private float speed = 6f;
	private Circle bounds;

	private float centerX;
	private float centerY;

	private boolean isIdle = true;

	private Items item = Items.FLASHLIGHT;

	private OrthographicCamera camera;
	private SpriteBatch batch;

	private Animation<TextureRegion> idle;
	private Animation<TextureRegion> walk;
	private Animation<TextureRegion> run;
	private Animation<TextureRegion> strafeLeft;
	private Animation<TextureRegion> strafeRight;
	private Animation<TextureRegion> flashlightIdle;
	private Animation<TextureRegion> flashlightMelee;
	private Animation<TextureRegion> flashlightMove;
	private Animation<TextureRegion> knifeIdle;
	private Animation<TextureRegion> knifeMelee;
	private Animation<TextureRegion> knifeMove;
	private Animation<TextureRegion> handgunIdle;
	private Animation<TextureRegion> handgunMelee;
	private Animation<TextureRegion> handgunMove;
	private Animation<TextureRegion> handgunReload;
	private Animation<TextureRegion> handgunShoot;
	private Animation<TextureRegion> rifleIdle;
	private Animation<TextureRegion> rifleMelee;
	private Animation<TextureRegion> rifleMove;
	private Animation<TextureRegion> rifleReload;
	private Animation<TextureRegion> rifleShoot;
	private Animation<TextureRegion> shotgunIdle;
	private Animation<TextureRegion> shotgunMelee;
	private Animation<TextureRegion> shotgunMove;
	private Animation<TextureRegion> shotgunReload;
	private Animation<TextureRegion> shotgunShoot;


	public Player(AssetLoader assetLoader, OrthographicCamera camera, SpriteBatch batch, float x, float y) {
		this.batch = batch;
		this.camera = camera;
		position = new Vector2(x, y);
		bounds = new Circle(x, y, 0);

		idle = assetLoader.getFeetIdle();
		walk = assetLoader.getFeetWalk();
		run = assetLoader.getFeetRun();
		strafeLeft = assetLoader.getFeetStrafeLeft();
		strafeRight = assetLoader.getFeetStrafeRight();

		flashlightIdle = assetLoader.getFlashlightIdle();
		flashlightMelee = assetLoader.getFlashlightMelee();
		flashlightMove = assetLoader.getFlashlightMove();

		knifeIdle = assetLoader.getKnifeIdle();
		knifeMelee = assetLoader.getKnifeMelee();
		knifeMove = assetLoader.getKnifeMove();

		handgunIdle = assetLoader.getHandgunIdle();
		handgunMelee = assetLoader.getHandgunMelee();
		handgunMove = assetLoader.getHandgunMove();
		handgunReload = assetLoader.getHandgunReload();
		handgunShoot = assetLoader.getHandgunShoot();

		rifleIdle = assetLoader.getRifleIdle();
		rifleMelee = assetLoader.getRifleMelee();
		rifleMove = assetLoader.getRifleMove();
		rifleReload = assetLoader.getRifleReload();
		rifleShoot = assetLoader.getRifleShoot();

		shotgunIdle = assetLoader.getShotgunIdle();
		shotgunMelee = assetLoader.getShotgunMelee();
		shotgunMove = assetLoader.getShotgunMove();
		shotgunReload = assetLoader.getShotgunReload();
		shotgunShoot = assetLoader.getShotgunShoot();

		idle.setPlayMode(PlayMode.LOOP);
		walk.setPlayMode(PlayMode.LOOP);
		run.setPlayMode(PlayMode.LOOP);
		strafeLeft.setPlayMode(PlayMode.LOOP);
		strafeRight.setPlayMode(PlayMode.LOOP);
		flashlightIdle.setPlayMode(PlayMode.LOOP);
		flashlightMelee.setPlayMode(PlayMode.LOOP);
		flashlightMove.setPlayMode(PlayMode.LOOP);
		knifeIdle.setPlayMode(PlayMode.LOOP);
		knifeMove.setPlayMode(PlayMode.LOOP);
		knifeMelee.setPlayMode(PlayMode.LOOP);
		handgunIdle.setPlayMode(PlayMode.LOOP);
		handgunMelee.setPlayMode(PlayMode.LOOP);
		handgunMove.setPlayMode(PlayMode.LOOP);
		handgunReload.setPlayMode(PlayMode.LOOP);
		handgunShoot.setPlayMode(PlayMode.LOOP);
		rifleIdle.setPlayMode(PlayMode.LOOP);
		rifleMelee.setPlayMode(PlayMode.LOOP);
		rifleMove.setPlayMode(PlayMode.LOOP);
		rifleReload.setPlayMode(PlayMode.LOOP);
		rifleShoot.setPlayMode(PlayMode.LOOP);
		shotgunIdle.setPlayMode(PlayMode.LOOP);
		shotgunMelee.setPlayMode(PlayMode.LOOP);
		shotgunMove.setPlayMode(PlayMode.LOOP);
		shotgunReload.setPlayMode(PlayMode.LOOP);
		shotgunShoot.setPlayMode(PlayMode.LOOP);
	}

	public Vector2 getPosition() {
		return position;
	}

	public float getOriginX() {
		return centerX;
	}

	public float getOriginY() {
		return centerY;
	}

	public float getSpeed() {
		return speed;
	}

	public Circle getBounds() {
		return bounds;
	}

	public boolean isIdle() {
		return isIdle;
	}

	public Items getCurrentItem() {
		return item;
	}

	public boolean move(float xx, float yy) {
		position.add(xx * speed, yy * speed);

		if (xx + yy > speed) {
			position = position.nor();
		}

		return true;
	}

	public void render(float delta, float gameState) {
		isIdle = true;
		boolean forward = false;
		boolean left = false;
		boolean right = false;

		Vector3 mouse = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
		mouse = camera.unproject(mouse);

		float mouseX = mouse.x;
		float mouseY = mouse.y;

		float deltaX = mouseX - centerX;
		float deltaY = mouseY - centerY;

		degrees = MathUtils.atan2(deltaY, deltaX) * MathUtils.radDeg;

		if (degrees < 0) {
			degrees += 360;
		}

		if (Gdx.input.isKeyPressed(Keys.W)) {
			isIdle = false;
			forward = true;
			move(0,1);
		}
		if (Gdx.input.isKeyPressed(Keys.A)) {
			isIdle = false;
			left = true;
			move(-1,0);
		}
		if (Gdx.input.isKeyPressed(Keys.S)) {
			isIdle = false;
			forward = true;
			move(0,-1);
		}
		if (Gdx.input.isKeyPressed(Keys.D)) {
			isIdle = false;
			right = true;
			move(1,0);
		}

		if (Gdx.input.isKeyJustPressed(Keys.NUM_1)) {
			item = Items.RIFLE;
		} else if (Gdx.input.isKeyJustPressed(Keys.NUM_2)) {
			item = Items.SHOTGUN;
		} else if (Gdx.input.isKeyJustPressed(Keys.NUM_3)) {
			item = Items.HANDGUN;
		} else if (Gdx.input.isKeyJustPressed(Keys.Q)) {
			item = Items.KNIFE;
		} else if (Gdx.input.isKeyJustPressed(Keys.F)) {
			item = Items.FLASHLIGHT;
		}

		TextureRegion moving = null;
		TextureRegion idling = null;
		TextureRegion feet = null;

		switch(item) {
		case KNIFE:
			moving = knifeMove.getKeyFrame(gameState);
			idling = knifeIdle.getKeyFrame(gameState);
			break;
		case FLASHLIGHT:
			moving = flashlightMove.getKeyFrame(gameState);
			idling = flashlightIdle.getKeyFrame(gameState);
			break;
		case HANDGUN:
			moving = handgunMove.getKeyFrame(gameState);
			idling = handgunIdle.getKeyFrame(gameState);
			break;
		case RIFLE:
			moving = rifleMove.getKeyFrame(gameState);
			idling = rifleIdle.getKeyFrame(gameState);
			break;
		case SHOTGUN:
			moving = shotgunMove.getKeyFrame(gameState);
			idling = shotgunIdle.getKeyFrame(gameState);
			break;
		}

		feet = walk.getKeyFrame(gameState);

		if (left && !forward) {
			feet = strafeLeft.getKeyFrame(gameState);
		} else if (right && !forward) {
			feet = strafeRight.getKeyFrame(gameState);
		}

		if (isIdle) {
			feet = idle.getKeyFrame(gameState);
		}

		if (isIdle) {
			centerX = position.x + (idling.getRegionWidth() / 2);
			centerY = position.y + (idling.getRegionHeight() / 2);
		} else {
			centerX = position.x + (moving.getRegionWidth() / 2);
			centerY = position.y + (moving.getRegionHeight() / 2);
		}

		bounds.setX(centerX);
		bounds.setY(centerY);

		if (!isIdle) {
			bounds.setRadius(((moving.getRegionWidth() + moving.getRegionHeight()) / 2) - 110);

			batch.draw(feet, centerX - (feet.getRegionWidth() / 2), centerY - (feet.getRegionHeight() / 2), feet.getRegionWidth() / 2, feet.getRegionHeight() / 2, feet.getRegionWidth(), feet.getRegionHeight(), 1f, 1f, degrees);
			batch.draw(moving, position.x, position.y, moving.getRegionWidth() /2, moving.getRegionHeight() / 2, moving.getRegionWidth(), moving.getRegionHeight(), 1f, 1f, degrees);
		} else {
			bounds.setRadius(((moving.getRegionWidth() + moving.getRegionHeight()) / 2) - 110);

			batch.draw(feet, centerX - (feet.getRegionWidth() / 2), centerY - (feet.getRegionHeight() / 2), feet.getRegionWidth() / 2, feet.getRegionHeight() / 2, feet.getRegionWidth(), feet.getRegionHeight(), 1f, 1f, degrees);
			batch.draw(idling, position.x, position.y, idling.getRegionWidth() /2, idling.getRegionHeight() / 2, idling.getRegionWidth(), idling.getRegionHeight(), 1f, 1f, degrees);
		}
	}

}
