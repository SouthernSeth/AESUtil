package com.jordan.game.entities;

public enum TileType {
	
	GRASS(0);
	
	private int id;
	
	TileType(int id) {
		this.id = id;
	}
	
	public int getID() {
		return id;
	}

}
