package com.jordan.game.entities;

public enum Items {

	FLASHLIGHT, KNIFE, HANDGUN, RIFLE, SHOTGUN;
	
}
