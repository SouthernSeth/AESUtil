package com.jordan.game.entities;

public class Zombie {

}
