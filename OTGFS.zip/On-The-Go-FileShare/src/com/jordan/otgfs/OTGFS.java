package com.jordan.otgfs;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.jordan.otgfs.network.AppClient;
import com.jordan.otgfs.network.AppServer;
import com.jordan.otgfs.screens.ConnectionScreen;
import com.jordan.otgfs.screens.FileListScreen;
import com.jordan.otgfs.screens.HostScreen;
import com.jordan.otgfs.screens.LoginScreen;

public class OTGFS {

	private JFrame window;
	private JPanel panel;

	private JButton host;
	private JButton connect;

	private JLabel logo;
	private JLabel creator;

	private OTGFS instance;

	private String COMPUTER_NAME;
	private String COMPUTER_IP;

	private String authToken;

	private AppClient client;
	private AppServer server;

	public OTGFS() {
		this.instance = this;

		client = new AppClient(instance);
		server = new AppServer(instance);

		COMPUTER_NAME = System.getProperty("user.name");

		String ip = null;
		try {
			Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			while (interfaces.hasMoreElements()) {
				NetworkInterface iface = interfaces.nextElement();
				if (iface.isLoopback() || !iface.isUp())
					continue;

				Enumeration<InetAddress> addresses = iface.getInetAddresses();
				while(addresses.hasMoreElements()) {
					InetAddress addr = addresses.nextElement();
					if (iface.getDisplayName().contains("Juniper") && !addr.getHostAddress().contains(":")) {
						ip = addr.getHostAddress();
					}
				}
			}
		} catch (SocketException e) {
			throw new RuntimeException(e);
		}

		if (ip == null) {
			JOptionPane.showMessageDialog(window, "Unable to get your IP address! Make sure that you are connected to the VPN!", "Connection Error", JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		} else {
			COMPUTER_IP = ip;
		}

		panel = new JPanel();
		panel.setPreferredSize(new Dimension(800,450));
		panel.setLayout(new GridBagLayout());

		host = new JButton("Host");
		connect = new JButton("Connect");

		creator = new JLabel("Developed by Jordan Wiggins � The Boeing Company");
		creator.setHorizontalAlignment(SwingConstants.CENTER);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 0.2;
		panel.add(getLogoComponent(), gbc);

		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.insets = new Insets(5,300,5,300);
		panel.add(host, gbc);

		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.insets = new Insets(5,300,100,300);
		panel.add(connect, gbc);

		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.SOUTH;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.insets = new Insets(0,0,5,0);
		panel.add(creator, gbc);

		window = new JFrame("OTG File Sharing");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setContentPane(panel);
		window.pack();
		window.setLocationRelativeTo(null);
		window.setMinimumSize(window.getSize());
		window.setVisible(true);
		window.setResizable(false);

		host.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				window.setContentPane(new HostScreen(instance));
				window.revalidate();
			}
		});

		connect.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				window.setContentPane(new ConnectionScreen(instance));
				window.revalidate();
			}
		});

		String[] options = new String[1];
		options[0] = new String("Agree");
		int ans = JOptionPane.showOptionDialog(window,"It is forbidden to transmit PII or HSPII using this system.\n"
				+ "By pressing AGREE you acknowledge that all data being transmitted\n"
				+ "is monitored and logged by the system. This tool should only be\n"
				+ "used to transmit work related material and nothing else!","Terms of Use Agreement", 0, JOptionPane.WARNING_MESSAGE,null,options,null);

		if (ans != 0) {
			System.exit(1);
		}		
	}

	public void fileListScreen() {
		window.setContentPane(new FileListScreen(instance));
		window.revalidate();
	}

	public void serverLogonScreen() {
		window.setContentPane(new LoginScreen(instance));
		window.revalidate();
	}

	public String getName() {
		return COMPUTER_NAME;
	}

	public String getIP() {
		return COMPUTER_IP;
	}

	public void setToken(String token) {
		this.authToken = token;
	}

	public String getToken() {
		return this.authToken;
	}

	public JFrame getWindow() {
		return window;
	}

	public AppClient getClient() {
		return client;
	}

	public AppServer getServer() {
		return server;
	}

	public JLabel getLogoComponent() {
		if (logo == null) {
			logo = new JLabel();
			try {
				BufferedImage img = ImageIO.read(getClass().getResourceAsStream("/logo.png"));
				Image img2 = img.getScaledInstance(500, 200, Image.SCALE_SMOOTH);

				logo.setIcon(new ImageIcon(img2));
				logo.setHorizontalAlignment(SwingConstants.CENTER);
				logo.setVerticalAlignment(SwingConstants.CENTER);

				return logo;
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			return logo;
		}
		return null;
	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new OTGFS();
			}
		});
	}

}
