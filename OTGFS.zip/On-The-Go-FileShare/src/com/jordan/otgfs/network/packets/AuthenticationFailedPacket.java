package com.jordan.otgfs.network.packets;

public class AuthenticationFailedPacket {

}
