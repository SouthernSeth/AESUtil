package com.jordan.otgfs.network.packets;

public class AuthenticationPacket {
	
	public boolean authenticated = false;
	public String password;

}
