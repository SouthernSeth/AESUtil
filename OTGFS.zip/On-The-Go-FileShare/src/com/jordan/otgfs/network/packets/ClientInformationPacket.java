package com.jordan.otgfs.network.packets;

public class ClientInformationPacket {
	
	public String name;
	public String ip;

}
