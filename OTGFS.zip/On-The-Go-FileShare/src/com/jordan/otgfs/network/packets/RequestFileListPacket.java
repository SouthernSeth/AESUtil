package com.jordan.otgfs.network.packets;

public class RequestFileListPacket {
	
	public String auth_token;
	public String fileName;

}
