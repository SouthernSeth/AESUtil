package com.jordan.otgfs.network.packets;

public class AuthTokenRequest {
	
	public String token;

}
