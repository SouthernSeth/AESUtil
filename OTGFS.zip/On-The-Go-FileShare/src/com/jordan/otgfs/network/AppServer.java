package com.jordan.otgfs.network;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import com.esotericsoftware.kryonet.Server;
import com.jordan.otgfs.OTGFS;
import com.jordan.otgfs.network.packets.AuthTokenRequest;
import com.jordan.otgfs.network.packets.AuthenticationFailedPacket;
import com.jordan.otgfs.network.packets.AuthenticationPacket;
import com.jordan.otgfs.network.packets.ClientInformationPacket;

public class AppServer {

	private OTGFS instance;
	private Server server;

	private boolean passwordProtected = false;

	private String hashedServerPassword;
	private HashMap<String, ArrayList<String>> permissions = new HashMap<String, ArrayList<String>>();
	private HashMap<String, String> authorized = new HashMap<String, String>();
	
	private ArrayList<File> files = new ArrayList<File>();

	public AppServer(OTGFS instance) {
		this.instance = instance;

		server = new Server() {
			@Override
			protected Connection newConnection() {
				return new AppConnection();
			}
		};
		Network.register(server);

		server.addListener(new Listener() {
			@Override
			public void connected(Connection c) {
				AppConnection con = (AppConnection) c;
				ClientInformationPacket packet = new ClientInformationPacket();
				con.sendTCP(packet);
			}

			@Override
			public void disconnected(Connection c) {
				AppConnection con = (AppConnection) c;
				String name = con.getName();
				
				if (name != null) {
					if (authorized.containsKey(name)) {
						authorized.remove(name);
					}
					System.out.println("'" + name + "' has disconnected from the server");
				}
			}

			@Override
			public void received(Connection c, Object o) {
				AppConnection con = (AppConnection) c;

				if (o instanceof ClientInformationPacket) {
					ClientInformationPacket packet = (ClientInformationPacket) o;
					con.setName(packet.name);
					con.setIP(packet.ip);

					if (isPasswordProtected()) {
						AuthenticationPacket packet2 = new AuthenticationPacket();
						con.sendTCP(packet2);
					} else {
						AuthenticationPacket packet3 = new AuthenticationPacket();
						
						AuthTokenRequest authToken = new AuthTokenRequest();
						authToken.token = generateAuthToken(con.getName());
						
						packet3.authenticated = true;
						con.setAuthenticated(true);
						
						con.sendTCP(packet3);
						con.sendTCP(authToken);
						System.out.println("'" + con.getName() + "' connected from '" + con.getIP() + "'");
					}
				} else if (o instanceof AuthenticationPacket) {
					AuthenticationPacket packet = (AuthenticationPacket) o;
					if (new String(packet.password).equalsIgnoreCase(hashedServerPassword)) {
						con.setAuthenticated(true);
						packet.authenticated = true;

						AuthTokenRequest authToken = new AuthTokenRequest();
						authToken.token = generateAuthToken(con.getName());

						con.sendTCP(packet);
						con.sendTCP(authToken);
						System.out.println("'" + con.getName() + "' connected from '" + con.getIP() + "'");
					} else {
						AuthenticationFailedPacket packet2 = new AuthenticationFailedPacket();
						con.sendTCP(packet2);
					}
				}
			}
		});

		server.start();
	}

	public void start(String hashedPassword, boolean isPasswordProtected) {
		this.hashedServerPassword = hashedPassword;
		this.passwordProtected = isPasswordProtected;

		try {
			server.bind(Network.PORT);
			System.out.println("Server has been started with parameters: Password Protected?=" + isPasswordProtected + ", Hashed Password=" + hashedPassword);
			instance.fileListScreen();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean isPasswordProtected() {
		return passwordProtected;
	}

	public ArrayList<String> getPermissions(String name) {
		if (!permissions.containsKey(name)) {
			System.out.println("'" + name + "' does not have any permissions specified");
			return null;
		}

		ArrayList<String> perms = permissions.get(name);
		return perms;
	}

	public boolean hasPermission(String name, String perm) {
		ArrayList<String> perms = getPermissions(name);

		if (perms == null) {
			return false;
		}

		for (String p : perms) {
			if (p.equalsIgnoreCase(perm)) {
				return true;
			}
		}

		return false;
	}

	public String generateAuthToken(String name) {
		ArrayList<String> values = new ArrayList<String>(authorized.values());

		try {
			boolean valid = false;
			byte[] token = new byte[16];
			SecureRandom secureRandom = SecureRandom.getInstanceStrong();

			if (values.isEmpty()) {
				secureRandom.setSeed(secureRandom.generateSeed(16));
				secureRandom.nextBytes(token);
				String translatedToken = Base64.getEncoder().encodeToString(token);
				authorized.put(name, translatedToken);
				return translatedToken;
			} else {
				while(!valid) {
					secureRandom.setSeed(secureRandom.generateSeed(16));
					secureRandom.nextBytes(token);
					String translatedToken = Base64.getEncoder().encodeToString(token);

					for (String v : values) {
						if (v.equalsIgnoreCase(translatedToken)) {
							break;
						}
					}

					valid = true;
				}

				String translatedToken = Base64.getEncoder().encodeToString(token);

				authorized.put(name, translatedToken);

				return translatedToken;
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return "null";
	}

}
