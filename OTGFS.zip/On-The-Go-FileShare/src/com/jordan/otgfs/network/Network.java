package com.jordan.otgfs.network;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.EndPoint;
import com.jordan.otgfs.network.packets.AuthTokenRequest;
import com.jordan.otgfs.network.packets.AuthenticationFailedPacket;
import com.jordan.otgfs.network.packets.AuthenticationPacket;
import com.jordan.otgfs.network.packets.ClientInformationPacket;
import com.jordan.otgfs.network.packets.RequestFileListPacket;

public class Network {
	
	public static final int PORT = 1234;
	
	public static void register(EndPoint endPoint) {
		Kryo kryo = endPoint.getKryo();
		
		kryo.register(String.class);
		kryo.register(byte.class);
		kryo.register(byte[].class);
		
		kryo.register(ClientInformationPacket.class);
		kryo.register(AuthenticationPacket.class);
		kryo.register(AuthenticationFailedPacket.class);
		kryo.register(RequestFileListPacket.class);
		kryo.register(AuthTokenRequest.class);
	}

}
