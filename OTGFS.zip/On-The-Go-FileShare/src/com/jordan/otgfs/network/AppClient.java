package com.jordan.otgfs.network;

import java.io.IOException;

import javax.swing.JOptionPane;

import com.esotericsoftware.kryonet.Client;
import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import com.jordan.otgfs.OTGFS;
import com.jordan.otgfs.network.packets.AuthTokenRequest;
import com.jordan.otgfs.network.packets.AuthenticationFailedPacket;
import com.jordan.otgfs.network.packets.AuthenticationPacket;
import com.jordan.otgfs.network.packets.ClientInformationPacket;

public class AppClient {

	private Client client;

	public AppClient(OTGFS instance) {
		client = new Client();
		Network.register(client);

		client.addListener(new Listener() {
			@Override
			public void connected(Connection c) {

			}

			@Override
			public void disconnected(Connection c) {
			}

			@Override
			public void received(Connection c, Object o) {
				if (o instanceof ClientInformationPacket) {
					ClientInformationPacket packet = (ClientInformationPacket) o;
					packet.ip = instance.getIP();
					packet.name = instance.getName();
					c.sendTCP(packet);
				} else if (o instanceof AuthenticationPacket) {
					AuthenticationPacket packet = (AuthenticationPacket) o;

					if (packet.authenticated == true) {
						instance.fileListScreen();
					} else {
						instance.serverLogonScreen();
					}
				} else if (o instanceof AuthenticationFailedPacket) {
					JOptionPane.showMessageDialog(instance.getWindow(), "The password you entered is incorrect for the file share!", "Login Error", JOptionPane.ERROR_MESSAGE);
				} else if (o instanceof AuthTokenRequest) {
					AuthTokenRequest authToken = (AuthTokenRequest) o;
					instance.setToken(authToken.token);
					System.out.println("Your client has been assigned auth token: " + authToken.token);
				}
			}
		});

		client.start();
	}

	public Client getClient() {
		return client;
	}

	public int connect(String ip) {
		try {
			client.connect(10000, ip, Network.PORT);
			return 1;
		} catch (IOException e) {
			e.printStackTrace();
			return 0;
		}
	}

}
