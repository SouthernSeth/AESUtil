package com.jordan.otgfs.network;

import com.esotericsoftware.kryonet.Connection;

public class AppConnection extends Connection {
	
	private String name;
	private String ip;
	private boolean connected = false;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setIP(String ip) {
		this.ip = ip;
	}
	
	public void setAuthenticated(boolean connected) {
		this.connected = connected;
	}
	
	public String getName() {
		return name;
	}
	
	public String getIP() {
		return ip;
	}
	
	public boolean isAuthenticated() {
		return connected;
	}

}
