package com.jordan.otgfs.screens;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import com.jordan.otgfs.OTGFS;

public class FileListScreen extends JPanel {
	
	private static final long serialVersionUID = -8961109242151216062L;
	
	private JList<String> files;
	private DefaultListModel<String> listModel;
	private JScrollPane scrollPane;
	
	public FileListScreen(OTGFS instance) {
		setPreferredSize(new Dimension(800,450));
		setLayout(new GridBagLayout());
		
		listModel = new DefaultListModel<String>();
		listModel.addElement("default_file.txt");
		listModel.addElement("Q3_Reports.xlsx");
		
		files = new JList<String>();
		files.setModel(listModel);
		
		scrollPane = new JScrollPane(files);
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		add(scrollPane, gbc);
		
		instance.getWindow().setResizable(true);
	}
	
	public void startRefresh() {
		Timer timer = new Timer();
		
		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				for(int i = 0;i<listModel.size();i++) {
					
				}
			}
		}, 1000L, 0L);
	}

}
