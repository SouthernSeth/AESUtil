package com.jordan.otgfs.screens;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JWindow;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import com.jordan.otgfs.OTGFS;

public class ConnectionScreen extends JPanel {
	
	private static final long serialVersionUID = 8581971493683618788L;
	
	private JLabel ipAddress;
	
	private JTextField ip;
	
	private JButton connect;
	
	public ConnectionScreen(OTGFS instance) {
		setPreferredSize(new Dimension(800,450));
		setLayout(new GridBagLayout());
		
		ipAddress = new JLabel("Server Address");
		ipAddress.setHorizontalAlignment(SwingConstants.CENTER);
		ipAddress.setFont(new Font("Calibri", Font.BOLD, 16));
		
		connect = new JButton("Connect");
		
		ip = new JTextField();
		ip.setText("Asset Tag or IP Address");
		
		ip.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				ip.selectAll();
			}
		});
		
		connect.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (ip.getText().isEmpty() || ip.getText().trim().isEmpty()) {
					JOptionPane.showMessageDialog(getParent(), "The address field cannot be left blank", "Connection Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				JWindow popup = showConnecting(ip.getText(), getParent());
				
				new Thread(){
					@Override
					public void run() {
						int status = instance.getClient().connect(ip.getText());
						
						if (status == 0) {
							popup.dispose();
							JOptionPane.showMessageDialog(getParent(), "Unable to connect to '" + ip.getText() + "' check the IP address and try again", "Connection Error", JOptionPane.ERROR_MESSAGE);
						} else {
							popup.dispose();
						}
					}
				}.start();
			}
		});
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		add(instance.getLogoComponent(), gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,250,0,250);
		add(ipAddress, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,275,15,275);
		add(ip, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,350,100,350);
		add(connect, gbc);
	}
	
	public JWindow showConnecting(String ip, Container container) {
		JWindow popup = new JWindow();
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.setPreferredSize(new Dimension(300,75));
		
		JLabel label = new JLabel("Connecting to " + ip + "...");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		panel.add(label, gbc);
		
		Border bord = BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.LIGHT_GRAY, Color.GRAY);
		panel.setBorder(bord);
		
		popup.setContentPane(panel);
		popup.pack();
		popup.setLocationRelativeTo(container);
		popup.setVisible(true);
		popup.setAlwaysOnTop(true);
		
		return popup;
	}

}
