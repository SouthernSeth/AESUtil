package com.jordan.otgfs.screens;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;

import com.jordan.otgfs.OTGFS;
import com.jordan.otgfs.network.packets.AuthenticationPacket;

public class LoginScreen extends JPanel {
	
	private static final long serialVersionUID = -2142385116679949353L;
	
	private JLabel serverPassword;
	private JLabel primPassword;
	
	private JButton logon;
	
	private JPasswordField password;

	public LoginScreen(OTGFS instance) {
		setPreferredSize(new Dimension(800,450));
		setLayout(new GridBagLayout());
		
		serverPassword = new JLabel("File Share Password");
		serverPassword.setHorizontalAlignment(SwingConstants.CENTER);
		serverPassword.setFont(new Font("Calibri", Font.BOLD, 16));
		
		primPassword = new JLabel("Password");
		
		logon = new JButton("Login");
		
		password = new JPasswordField();
		
		logon.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AuthenticationPacket packet = new AuthenticationPacket();
				
				MessageDigest digest = null;
				try {
					digest = MessageDigest.getInstance("SHA-256");
				} catch (NoSuchAlgorithmException e1) {
					e1.printStackTrace();
				}
				
				byte[] hashedPassword = digest.digest(new String(password.getPassword()).getBytes());
				String pass = Base64.getEncoder().encodeToString(hashedPassword);
				
				packet.password = pass;
				instance.getClient().getClient().sendTCP(packet);
			}
		});
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		add(instance.getLogoComponent(), gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,250,10,250);
		add(serverPassword, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,275,0,275);
		add(primPassword, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,275,15,275);
		add(password, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,350,100,350);
		add(logon, gbc);
	}

}
