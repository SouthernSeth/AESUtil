package com.jordan.otgfs.screens;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;

import com.jordan.otgfs.OTGFS;

public class HostScreen extends JPanel {

	private static final long serialVersionUID = -1797198316626386298L;

	private JLabel serverPassword;
	private JLabel primPassword;
	private JLabel confPassword;

	private JButton start;

	private JPasswordField password;
	private JPasswordField confirmPassword;

	public HostScreen(OTGFS instance) {
		setPreferredSize(new Dimension(800,450));
		setLayout(new GridBagLayout());
		
		serverPassword = new JLabel("File Share Password Protection");
		serverPassword.setHorizontalAlignment(SwingConstants.CENTER);
		serverPassword.setFont(new Font("Calibri", Font.BOLD, 16));
		
		primPassword = new JLabel("Password");
		confPassword = new JLabel("Confirm Password");
		
		start = new JButton("Start");
		
		password = new JPasswordField();
		confirmPassword = new JPasswordField();
		
		start.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (password.getPassword().length == 0 && confirmPassword.getPassword().length == 0) {
					int ans = JOptionPane.showConfirmDialog(getParent(), "You have not entered a password, this means that anyone with the server IP can connect.\n Do you want to continue without a password protected server?", "Non-Password Protected Confirmation", JOptionPane.YES_NO_OPTION);
					if (ans == JOptionPane.YES_OPTION) {
						instance.getServer().start(null, false);
					}
				} else if (isMatch(password, confirmPassword)) {
					MessageDigest digest = null;
					try {
						digest = MessageDigest.getInstance("SHA-256");
					} catch (NoSuchAlgorithmException e1) {
						e1.printStackTrace();
					}
					
					byte[] hashedPassBytes = digest.digest(new String(password.getPassword()).getBytes());
					String hashedPass = Base64.getEncoder().encodeToString(hashedPassBytes);
					
					instance.getServer().start(hashedPass, true);
				} else {
					JOptionPane.showMessageDialog(getParent(), "The passwords you have entered do not match!", "Passwords Error", JOptionPane.ERROR_MESSAGE);
				}
				//TODO: Make sure passwords match, and begin server
				//TODO: If password is blank then user should get a prompt saying the server will not be password protected, once they confirm it will start
			}
		});
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		add(instance.getLogoComponent(), gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,250,10,250);
		add(serverPassword, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,275,0,275);
		add(primPassword, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,275,5,275);
		add(password, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,275,0,275);
		add(confPassword, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,275,15,275);
		add(confirmPassword, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 6;
		gbc.weightx = 1;
		gbc.insets = new Insets(5,350,100,350);
		add(start, gbc);
	}
	
	private boolean isMatch(JPasswordField pass, JPasswordField confirmPass) {
		char[] pass1 = pass.getPassword();
		char[] pass2 = confirmPass.getPassword();
		
		if (pass1.length != pass2.length) {
			return false;
		}
		
		for (int i = 0;i<pass1.length;i++) {
			if (pass1[i] != pass2[i]) {
				return false;
			}
		}
		
		return true;
	}

}
