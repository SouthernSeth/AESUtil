package me.southernseth.litecryptor;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import me.southernseth.litecryptor.util.RSAUtil;
import me.southernseth.litecryptor.window.CertificateManagerWindow;
import me.southernseth.litecryptor.window.CreateCertificateWindow;

public class LiteCryptor {

	private final String APPLICATION_NAME = "LiteCrypto";
	private final String APPLICATION_VERISON = "1.0.0";
	
	private JFrame window;
	private JPanel panel;
	
	private JMenuBar menuBar;
	
	private JMenu file;
	
	private JMenuItem exit;
	private JMenuItem manageCertificates;
	private JMenuItem generateCerts;
	
	private static File certStore;
	
	private static LiteCryptor instance;
	
	public LiteCryptor() {
		instance = this;
		
		certStore = new File(System.getProperty("user.home") + "\\.LiteCrypto");
		if (!certStore.exists()) {
			certStore.mkdirs();
		}
		
		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.setPreferredSize(new Dimension(600, 200));
		
		menuBar = new JMenuBar();
		file = new JMenu("File");
		exit = new JMenuItem("Exit");
		manageCertificates = new JMenuItem("Manage Certificates");
		generateCerts = new JMenuItem("Generate Key Pair");
		
		exit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		
		manageCertificates.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new CertificateManagerWindow(instance);
			}
		});
		
		generateCerts.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new CreateCertificateWindow(instance);
			}
		});
		
		file.add(generateCerts);
		file.add(manageCertificates);
		file.addSeparator();
		file.add(exit);
		
		menuBar.add(file);
		
		JButton encryptText = new JButton("Encrypt Text");
		JButton encryptFiles = new JButton("Encrypt Files");
		JButton decryptText = new JButton("Decrypt Text");
		JButton decryptFiles = new JButton("Decrypt Files");
		
		Font f = new Font("Calibri", Font.BOLD, 20);
		encryptText.setFont(f);
		decryptText.setFont(f);
		encryptFiles.setFont(f);
		decryptFiles.setFont(f);
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weighty = 1;
		gbc.weightx = 0.25;
		gbc.insets = new Insets(25,5,25,5);
		panel.add(encryptText, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weighty = 1;
		gbc.weightx = 0.25;
		gbc.insets = new Insets(25,5,25,5);
		panel.add(decryptText, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.weighty = 1;
		gbc.weightx = 0.25;
		gbc.insets = new Insets(25,5,25,5);
		panel.add(encryptFiles, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 3;
		gbc.gridy = 0;
		gbc.weighty = 1;
		gbc.weightx = 0.25;
		gbc.insets = new Insets(25,5,25,5);
		panel.add(decryptFiles, gbc);
		
		window = new JFrame(APPLICATION_NAME + " v" + APPLICATION_VERISON);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setJMenuBar(menuBar);
		window.setContentPane(panel);
		window.pack();
		window.setLocationRelativeTo(null);
		window.setMinimumSize(window.getSize());
		window.setResizable(false);
		window.setVisible(true);
		
		CertificateManager.initialize();
		
		if (CertificateManager.getLoadedCertificates().size() < 1) {
			JOptionPane.showMessageDialog(window, "We couldn't find a public and private key on your computer! You need to generate a pair in order to encrypt/decrypt!", "Unable to find keys", JOptionPane.ERROR_MESSAGE);
			new CreateCertificateWindow(instance);
		}
	}
	
	public JFrame getWindow() {
		return window;
	}
	
	public static String certStorePath() {
		return certStore.getAbsolutePath();
	}
	
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (UnsupportedLookAndFeelException | ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		
		RSAUtil.generateKeys("jordan.s.wiggins@boeing.com", "testing123", new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8 }, System.getProperty("user.home") + "\\.LiteCrypto");
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new LiteCryptor();
			}
		});
	}
	
}
