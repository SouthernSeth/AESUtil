package me.southernseth.litecryptor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Base64;

import me.southernseth.litecryptor.util.LCCertificate;

public class CertificateManager {
	
	private static boolean initialized = false;
	
	private static ArrayList<LCCertificate> loadedCerts = new ArrayList<LCCertificate>();
	
	public static void initialize() {
		String certStore = LiteCryptor.certStorePath();
		
		File f = new File(certStore + "\\certs");
		if (!f.exists()) {
			f.mkdirs();
		}
		
		File[] certs = f.listFiles();
		if (certs.length > 0) {
			for (int i = 0;i<certs.length;i++) {
				File c = certs[i];
				if (c.getName().contains(".lcc")) {
					LCCertificate cert = parseCertFile(c);
					loadedCerts.add(cert);
				}
			}
		}
		
		initialized = true;
	}
	
	public static String parseLCKeyEmail(String key) {
		String tmp = key.replace("---------- LiteCrypto Public ----------", "");
		tmp = tmp.replaceAll("\n", "");
		tmp = tmp.trim();
		System.out.println(tmp);
		return new String(Base64.getDecoder().decode(tmp.split("#")[0].getBytes()));
	}
	
	public static String parseLCKeyEncodedPublicKey(String key) {
		String tmp = key.replace("---------- LiteCrypto Public ----------", "");
		tmp = tmp.replaceAll("\n", "");
		tmp = tmp.trim();
		return tmp.split("#")[1];
	}
	
	public static ArrayList<LCCertificate> getLoadedCertificates() {
		return loadedCerts;
	}

	public static void removeCertificateByIdentifer(String identifer) {
		int index = 0;
		
		for (int i = 0;i<loadedCerts.size();i++) {
			LCCertificate cert = loadedCerts.get(i);
			if (cert.identifier.equalsIgnoreCase(identifer)) {
				index = i;
				break;
			}
		}
		
		loadedCerts.remove(index);
	}
	
	public static void removeCertificateByEmail(String email) {
		int index = 0;
		
		for (int i = 0;i<loadedCerts.size();i++) {
			LCCertificate cert = loadedCerts.get(i);
			if (cert.email.equalsIgnoreCase(email)) {
				index = i;
				break;
			}
		}
		
		loadedCerts.remove(index);
	}
	
	public static LCCertificate getCertificateByIdentifier(String identifer) {
		for (LCCertificate c : loadedCerts) {
			if (c.identifier.equalsIgnoreCase(identifer)) {
				return c;
			}
		}
		return null;
	}
	
	public static LCCertificate getCertificateByEmail(String email) {
		for (LCCertificate c : loadedCerts) {
			if (c.email.equalsIgnoreCase(email)) {
				return c;
			}
		}
		return null;
	}
	
	public static void createCertificateStorage(String identifier, String email, String hashedPassword, PublicKey pk, PrivateKey privk) {
		if (initialized == false) {
			return;
		}
		
		File tmp = new File(LiteCryptor.certStorePath() + "\\certs\\" + identifier + ".lcc");
		
		if (tmp.exists()) {
			return;
		}
		
		try {
			tmp.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(tmp));
			
			bw.write("email=" + email + "\n");
			bw.write("hashed_password=" + hashedPassword + "\n");
			bw.write("public_cert=" + Base64.getEncoder().encodeToString(pk.getEncoded()) + "\n");
			bw.write("private_cert=" + Base64.getEncoder().encodeToString(privk.getEncoded()));
			
			bw.flush();
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		LCCertificate cert = new LCCertificate();
		cert.identifier = identifier;
		cert.email = email;
		cert.hashedPassword = hashedPassword;
		cert.base64publicKey = Base64.getEncoder().encodeToString(pk.getEncoded());
		cert.base64privateKey = Base64.getEncoder().encodeToString(privk.getEncoded());
		loadedCerts.add(cert);
	}

	public static void createCertificateStorage(String identifier, String email, PublicKey pk) {
		if (initialized == false) {
			return;
		}
		
		File tmp = new File(LiteCryptor.certStorePath() + "\\certs\\" + identifier + ".lcc");
		
		if (tmp.exists()) {
			return;
		}
		
		try {
			tmp.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(tmp));
			
			bw.write("email=" + email + "\n");
			bw.write("public_cert=" + Base64.getEncoder().encodeToString(pk.getEncoded()));
			
			bw.flush();
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		LCCertificate cert = new LCCertificate();
		cert.identifier = identifier;
		cert.email = email;
		cert.base64publicKey = Base64.getEncoder().encodeToString(pk.getEncoded());
		loadedCerts.add(cert);
	}
	
	private static LCCertificate parseCertFile(File f) {
		LCCertificate cert = new LCCertificate();
		
		cert.identifier = f.getName().replace(".lcc", "");
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String str = null;
			
			while ((str = br.readLine()) != null) {
				String[] split = str.split("=");
				
				if (split.length == 2) {
					if (split[0].equalsIgnoreCase("email")) {
						cert.email = split[1];
					} else if (split[0].equalsIgnoreCase("hashed_password")) {
						cert.hashedPassword = split[1];
					} else if (split[0].equalsIgnoreCase("public_cert")) {
						cert.base64publicKey = split[1];
					} else if (split[0].equalsIgnoreCase("private_cert")) {
						cert.base64privateKey = split[1];
					}
				}
			}
			
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return cert;
	}
	
}
